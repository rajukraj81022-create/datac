// Traveling Salesman algorithms using recursion with visited tracking
/*
public class TSP
{
    static int Sales(int arr[][], int row, int n, int count, boolean[] visited)
    {
        // Base case: if all cities are visited, stop recursion
        if(count == n)
        {
            return 0;
        }

        Integer min = null;

        for (int i = 0; i < n; i++)
        {
            int value = arr[row][i];

            // Only consider unvisited cities with a path
            if(value != 0 && !visited[i])
            {
                visited[i] = true; // mark city as visited
                int total = value + Sales(arr, i, n, count + 1, visited);

                if(min == null || total < min)
                {
                    min = total;
                }

                visited[i] = false; // backtrack
            }
        }

        return (min == null) ? 0 : min;
    }

    public static void main(String[] args)
    {
        int [][]arr = {
            {0,5,0,6,0,4,0,7},
            {5,0,2,4,3,0,0,0},
            {0,2,0,1,0,0,0,0},
            {6,4,1,0,7,0,0,0},
            {0,3,0,7,0,0,6,4},
            {4,0,0,0,0,0,3,8},
            {0,0,0,0,6,3,0,2},
            {7,0,0,0,4,8,2,0}
        };

        int n = arr.length;
        boolean[] visited = new boolean[n];
        visited[0] = true; // start from city 0

        int cost = Sales(arr, 0, n, 1, visited);
        System.out.print("Minimum cost: " + cost);
    }
}
*/
public class TSP
{
	static int partion(int arr[],int low,int high)
	{
		int i=low-1;
		int j=0;
		int pivot=arr[high];
		for(j=low;j<high;j++)
		{
			if(arr[j]<pivot)
			{
				i++;
				swap(arr[i],arr[j]);
			}
		}
			swap(arr[i+1],arr[j]);
			return i+1;
	}
	static int QuickSort(int arr[],int low,int high)
	{
		if(low<high)
		{
			int pi=partion(arr,low,high);
			QuickSort(arr,low,pi-1);
			QuickSort(arr,pi+1,high);
			
		}
	}
	public static void main(String[] args)
	{
		int arr[]={1,3,1,4,0,7}
		
	}
	
}
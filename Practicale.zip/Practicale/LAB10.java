public class LAB10
{
	public static void main(String[] args)
	{
		int profit[]={25,24,15};
		int weight[]={18,15,10};
		int n=profit.length;
		double[] Ratio = new double[n];
		for(int i=0;i<n;i++)
		{
			 Ratio[i]=profit[i]/weight[i];
		}
		for(int i=0;i<n-1;i++)
		
			for(int j=0;j<n-i-1;j++)
			{
				if(Ratio[j]<Ratio[j+1])
				{
					double tempR=Ratio[j];
					Ratio[j]=Ratio[j+1];
					Ratio[j+1]=tempR;
					//swap Profit
					int tempP = profit[i];
                    profit[i] = profit[j];
                    profit[j] = tempP;

                    // Swap weight
                    int tempW = weight[i];
                    weight[i] = weight[j];
                    weight[j] = tempW;
					
				}
				
			}
		}
			
		int max=20;
		double TotalProfit=0;
		for(int i=0;i<n;i++)
		{
			if(max>weight[i])
			{
				TotalProfit+=profit[i];
				max-=weight[i];
			}
			else
			{
				TotalProfit+=(profit[i]/weight[i])*max;
				max=0;
			}
		}	
		System.out.print(TotalProfit);	
	}
	

	
}
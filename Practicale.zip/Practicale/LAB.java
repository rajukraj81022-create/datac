/*Searching Algorithms (with the number of key comparisons) - Sequential, Binary and 
Fibonacci search algorithms 
*/ 


// lINEAR SEARCH

/*

import java.util.Scanner;
public class LAB
{
	static int LinearSearch(int arr[],int size,int target)
	{
		for(int i=0;i<size;i++)
		{
			if(arr[i]==target)
			{
				return i;
			}
			
		}
		return -1;
	}
	public static void main(String[]args)
	{
		int arr[]={23,14,25,14,16,12,22};
		int size=arr.length;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the element which you want to find\n");
		int element=sc.nextInt();
        int index=LinearSearch(arr,size,element);
		if(index!=-1)
		{
			System.out.println("Index of Array is: "+index);
		}
		else
		{
			System.out.println("Element not found in Given Array");
			
		}
	}
}

*/


//  Binary Search


/*

import java.util.Scanner;
public class LAB
{
	static int Sort(int arr[],int size,int target)
	{
		int temp;
		for(int i=0;i<size;i++)
		{
			for(int j=0;j<size-1;j++)
			{
				if(arr[j]>arr[j+1])
				{
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
					
				}
			}
			
		}
		 for(int i=0;i<size;i++)
		 {
			 System.out.println(arr[i]);
		 }
		 int index;
			index=BinarySearch(arr,size,target);
			return index;
	}
	static int BinarySearch(int arr[],int size,int target)
	{
		int low=0;
		int high=size-1;
		int mid;
		
		while(low<=high)
		{
		
			 mid = (low +high) / 2;
			if(arr[mid]==target)
			{
				return mid;
			}
			else if(arr[mid]<target)
			{
				low=mid+1;
			}
			else{
			  high=mid-1;
			}
		}
		return-1;
	}
	 
	
	   public static void main(String[]args)
	{
		int arr[]={12,11,1,16,2,22,23,34,21};
		int size=arr.length;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the element which you want to find\n");
		int element=sc.nextInt();
		System.out.println("Sorted array is:");
		 int index=Sort( arr, size,element);
		if(index!=-1)
		{
			System.out.println("Index of Array is: "+index);
		}
		else
		{
			System.out.println("Element not found in Given Array");
			
		}
		
	}

	}

*/



//Fibbonacci Search

import java.util.Scanner;
public class LAB{
	static int Fibbo(int arr[],int target)
	{
		int n=arr.length;
		int fib1=0;
		int fib2=1;
		int fib=fib1+fib2;
		while(fib<=n)
		{
			fib2=fib1;
			fib2=fib;
			fib=fib1+fib2;
			
		}
		int offset=-1;
		while(fib>1)
		{
			int i=Min(offset+fib2,n-1);
			if(arr[i]<target)
			{
				fib=fib1;
				fib1=fib2;
				fib2=fib-fib1;
			}
			else if(arr[i]>target)
			{
				fib=fib2;
				fib1=fib-fib2;
				fib2=fib-fib1;
			}
			else
			{
				return i;
			}
		}
		if(fib==1 &arr[offset]==target)
		{
			return offset+1;
		}
		else 
			return -1;
	}
	
public static void main(String[] args)
{
	int First=0;
	int Second=1;
	int arr[]={12,13,15,16,20,22,23,34,37};
	Scanner sc=new Scanner(System.in);
	int target=sc.nextInt();
    int index=Fibbo(arr,target);
    if(index!=-1)
	{
		System.out.println("Index of element"+index);
	}
	else{
	  System.out.println("Elment not found");
	}
}	
	
	


}
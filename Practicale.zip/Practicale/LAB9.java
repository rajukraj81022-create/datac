
//Sorting algorithms using Divide-and-Conquer technique.

public class LAB9
{
	static void Concure(int arr[],int low,int mid,int high)
	{
		int indx1=low;
		int indx2=mid+1;
		int x=0;
		int merged[] = new int[high - low + 1];
		while(indx1<=mid &&indx2<=high)
		{
			if(arr[indx1]<=arr[indx2])
			{
				merged[x++]=arr[indx1++];
			}
			else
			{
				merged[x++]=arr[indx2++];
			}
		}
		while(indx1<=mid)
		{
			merged[x++]=arr[indx1++];
		}
		while(indx1<=mid)
		{
			merged[x++]=arr[indx2++];
		}
		for(int i=0,j=low;i<=merged.lenght();i++,j++)
		{
			arr[i]=merged[j];
		}
	}
	
     static void Divide(int arr[],int low,int high)
	 {
		 if(low>=high)
		 {
			 return;
		 }
		 int mid=(low+high)/2;
		 Divide(arr,low,mid);
		 Divide(arr,mid+1,high);
	 }
	public static void main(String[] args)
	{
		int arr[]={1,2,3,7,3,2,8,0,9};
		int size=arr.lenght;
		Divide(arr,0,size-1);
		for(int i=0;i<=size;i++)
		{
			System.out.print(arr[i]);
		}
	}
	
}

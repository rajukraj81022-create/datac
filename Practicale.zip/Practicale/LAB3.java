   //  3. Stack, Queue, Circular queue, priority queue 
   
   // Satck Operation 
 /*  
public class LAB3
{
	static class Stack
	{
	
		int data;
		int top;
		int size;
		int []arr;
		Stack()
		{
			this.top=-1;
			this.size=6;
			this.arr=new int[size];
	    }
	int IsEmpty()
	{
		if(top==-1)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	int IsFull()
	{
		if(top==size-1)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	void Push(int data)
	{
		if(IsFull()==1)
		{
			System.out.println("Stack is Overflow");
		}
		else
		{
			arr[++top]=data;
		}
	}
	void Display()
	{
		for(int i=top;i>=0;i--)
		{
		System.out.println(arr[i]);
		}
	}
	int Pop()
	{                           
		int val=arr[top--];
		return val;
	}
	 int peek(int i)
	 {
		 int index=top-i+1;
		 if(index<0)
		 {
			 System.out.println("You Enter Envalid Position");
			 return -1;
		 }
		 else{
			 return arr[index];
		 }
	}
	}
	public static void main(String[] args)
	{
		Stack obj=new Stack();
		System.out.println(obj.IsEmpty());
		System.out.println(obj.IsFull());
		obj.Push(3);
		obj.Push(5);
		obj.Push(13);
		obj.Push(65);
		obj.Push(31);
		obj.Push(32);
		System.out.println("Before pop");
		obj.Display();
		System.out.println(obj.Pop());
		System.out.println(obj.Pop());
		System.out.println("After pop");
		obj.Display();
	    for(int i=1;i<obj.top+1;i++)
		{
			System.out.println("The value at position " + i + " = " +obj.peek(i));
		
        }

}
}

*/


// Operation In QUEUE

/*

public class LAB3
{
	static class QUEUE
	{
		int Rear;
		int Front;
		int size;
		int []arr;
	 QUEUE()
	 {
	    this.Rear=-1;
		this.Front=-1;
		this.size=7;
		this.arr=new int[size];
     }
	 int IsEmpty()
	 {
		 if(Rear==-1 &&Front==-1)
		 {
            return 1;
		 }
         else
		 {
			 return 0;
		 }
		 
	 }
	 int IsFull()
	 {
		 if(Rear==size-1)
		 {
			 return 1;
		 }
		 else
		 {
			 return 0;
		 }
	}
	void Inqueue(int data)
	{
		if(IsFull()==1)
		{
			System.out.println("Queue is Full");
		}
		else
		{
	     if(Front==-1)
		 {
			 Front=0;
		 }
		arr[++Rear]=data;
		}
	}
	void Display()
	{
		for(int i=Front;i<Rear;i++)
		{
			System.out.println("Element in Queue:  "  +arr[i]);
		}
	}
		
	int Dequeue()
	{
		
		if(IsEmpty()==1 )
		{
			System.out.println("Queue is under flow");
			return -1;
		}
		else
		{
          return arr[Front++];
		}
	}
	}
	public static void main(String [] args)
	{
	QUEUE obj=new QUEUE();
	System.out.println(obj.IsEmpty());
	System.out.println(obj.IsFull());
	obj.Inqueue(12);
	obj.Inqueue(34);
	obj.Inqueue(67);
	obj.Inqueue(80);
	obj.Inqueue(56);
	obj.Inqueue(67);
	obj.Inqueue(89);
	obj.Inqueue(89);
	obj.Inqueue(89);
	System.out.println("After Inqueue ");
	obj.Display();
	System.out.println("Pop Element From Queue: "+obj.Dequeue());
    System.out.println("Pop Element From Queue: "+obj.Dequeue());
	System.out.println("After Dequeue");
	obj.Display();

	
	}
}
	
*/


// Circular Queue


public class LAB3
{
	static class CirQueue
	{
		int Rear;
		int Front;
		int size;
		int []arr;
		int count;
		CirQueue()
		{
			this.Rear=-1;
			this.Front=0;
			this.size=6;
			this.count=0;
			this.arr=new int[size];
		}
		int IsEmpty()
		{
			if(count==0)
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}
		int IsFull()
		{
			if(count==size-1)
			{
				return 1;
			}
			else{
				return 0;
			}
		
		}
		void Dispaly()
		{
			int i=Front;
			for(int c=0;c<count;c++)
			{
				System.out.println("Index of elment:"+ i +" " +arr[i]);
				i=(i+1)%size;
			}
		}
		void Inqueue(int data)
		{
			if(IsFull()==1)
			{
				System.out.println("Queue is Full");
			}
			else
			{
				
			Rear=(Rear+1)%size;
			arr[Rear]=data;
			count++;
			}
		}
		int Dequeue()
		{
			if(IsEmpty()==1)
			{
				System.out.println("Queue is Empty");
				return -1;
			}
			else
			{
				int val=arr[Front];
				Front=(Front+1)%size;
				count--;
				return val;
				
			}
		}
				
	}
		public static void main(String[] args)
		{
			CirQueue obj=new CirQueue();
			System.out.println(obj.IsEmpty());
			System.out.println(obj.IsFull());
			System.out.println("After Inqueue");
			obj.Inqueue(34);
			obj.Inqueue(24);
			obj.Inqueue(12);
			obj.Inqueue(26);
			obj.Inqueue(56);
			obj.Inqueue(89);
			obj.Inqueue(80);
			obj.Inqueue(56);
			obj.Dispaly();
			
			System.out.println("DeQueue Element"+ obj.Dequeue());
		    System.out.println("DeQueue Element"+ obj.Dequeue());
			System.out.println("DeQueue Element"+ obj.Dequeue());
			System.out.println("After Dequeue");
			obj.Dispaly();
			
		
	}
}	








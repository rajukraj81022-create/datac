//  Evaluation of arithmetic expression. 
  


public class LAB2
{
    static class Post
	{
		
      String str;
	 double[]stack = new double[100];
	 int top=0;
	 int Operator(char ch)
	{
		if(ch=='+'||ch=='*'||ch=='/'||ch=='-')
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	 void push(double data)
	{
		stack[top]=data;
		top++;
	}
	 double pop()
	{
		top--;
		return stack[top];
	}
	 double PostFix()
	{
		for(int i=0;i<=str.length()-1;i++)
		{
			char Ch=str.charAt(i);
			if(Operator(Ch)==1)
			{
				double val1=pop();
				double val2=pop();
				double result=0;
				switch(Ch)
				{
					case'+':
					result=val2+val1;
					break;
					case'*':
					result=val2*val1;
					break;
					case'/':
					result=val2/val1;
					break;
					case'-':
					result=val2-val1;
					break;
				}
				push(result);
			}
			else
			{
              push(Ch-'0');
			}
		}
		return pop();
	}
	}
	public static void main(String[] args)
	{
		Post obj= new Post();
		obj.str="12/34*-3*";
      System.out.print(obj.PostFix());
		
		
	}
}



public class LABNode {

    // Traverse circular linked list
    void Traverse(LABNode head) {
        if (head == null) return;

        LABNode temp = head;
        do {
            System.out.println(temp.data);
            temp = temp.next;
        } while (temp != head);
    }

    // Insert a node at a given position in a circular linked list
    LABNode InsertNode(LABNode head, int index, int value) {

        LABNode newNode = new LABNode();
        newNode.data = value;

        // Insert at beginning (index = 0)
        if (index == 0) {
            if (head == null) {   // Empty list
                newNode.next = newNode;
                return newNode;
            } else {              // Non-empty circular list
                LABNode temp = head;
                while (temp.next != head) {
                    temp = temp.next;
                }
                temp.next = newNode;
                newNode.next = head;
                return newNode;  // New head
            }
        }

        // Insert at index > 0
        LABNode temp = head;
        int count = 0;

        while (temp.next != head && count < index - 1) {
            temp = temp.next;
            count++;
        }

        if (count != index - 1) {     // Index out of range
            System.out.println("Out of Bound");
            return head;
        }

        // Insert at last position (temp.next == head)
        if (temp.next == head) {
            newNode.next = head;
            temp.next = newNode;
            return head;
        }

        // Insert in middle
        newNode.next = temp.next;
        temp.next = newNode;
        return head;
    }

    public static void main(String[] args) {
        LABNode obj = new LABNode();

        // Creating circular linked list manually
        LABNode n1 = new LABNode();
        LABNode n2 = new LABNode();
        LABNode n3 = new LABNode();
        LABNode n4 = new LABNode();

        n1.data = 45; 
		n1.next = n2;
        n2.data = 40; 
		n2.next = n3;
        n3.data = 85; 
		n3.next = n4;
        n4.data = 95;
  n4.next = n1;  // circular link

        System.out.println("Before insertion:");
        obj.Traverse(n1);

        System.out.println("After insertion:");
        n1 = obj.InsertNode(n1, 1, 56); // insert 56 at index 1
        obj.Traverse(n1);
    }
}

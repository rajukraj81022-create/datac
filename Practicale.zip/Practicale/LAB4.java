

//Singly Linked List, Doubly Linked List, Circular Linked List.


// Singly LInked list 
/*

public class LAB4
{
	static class Node
	{
       int data;
	   Node next;
	}
	void Traverse(Node ptr)
	{
		Node temp=new Node();
		temp=ptr;
		while(temp!=null)
		{
			System.out.println(temp.data);
			temp=temp.next;
		}
	}
	Node InsertAtNode(Node head,Node p,int data)
	{
		Node temp=new Node();
		temp=head;
		Node newnode=new Node();
		newnode.data=data;
		if(p==head)
		{
			newnode.next=head;
			head=newnode;
			return head;
		}
		else
		{
		while(temp.next!=null &&temp.next!=p)
		{
			temp=temp.next;
		}
		if(temp==null)
		{
			System.out.println("Out of Bound");
			return head;
		}
		newnode.next=temp.next;
		temp.next=newnode;
		return head;
		
	   }
		
	}
	Node DeleteAt(Node head,Node ptr)
	{
		Node temp=new Node();
		temp=head;
		if(temp.next==null)
		{
			System.out.println("Given Node is Out of Bound");
			return head;
		}
		if(ptr==head)
		{
			return head.next;
		}
		 if(ptr == null) {
        System.out.println("Given node is NULL (Out of Bound)");
        return head;
    }
		else{
			
		while(temp.next!=null && temp.next!=ptr)
		{
			temp=temp.next;
		}
		
		  temp.next=ptr.next;
		  return head;

		}
		
	}
	public static void main(String[] args)
	{
		LAB4 obj=new LAB4();
		Node head=new Node();
		Node second=new Node();
		Node third=new Node();
		Node four=new Node();
		head.data=56;
		head.next=second;
		second.data=50;
		second.next=third;
		third.data=36;
		third.next=four;
		four.data=86;
		four.next=null;
		obj.Traverse(head);
		System.out.println("After insert at any Node");
		head=obj.InsertAtNode(head,head,45);
		obj.Traverse(head);
		System .out.println("After Delete the Node");
		head=obj.DeleteAt(head,second);
		obj.Traverse(head);
	
		
		
	}

}

*/

// Duubly Linked List

/*

public class LAB4
{
	static class Node
	{
		int data;
		Node next;
	    Node preq;
	}
	void Traverse(Node head)
	{
		Node temp=new Node();
		temp=head;
		while(temp!=null)
		{
			System.out.println(temp.data);
			temp=temp.next;
		}
	}
	Node InsertNode(Node head,int index,int data)
	{
		Node temp=new Node();
		Node ptr=new Node();
		ptr.data=data;
		temp=head;
		int i=0;
		if(index<0)
		{
			System.out.println("Not Valid Index");
		}
		if(index==0)
		{
			ptr.next=head;
			if(head!=null)
			{
				
			head.preq=ptr;
			}
			head=ptr;
			return head;
			
		}
		
		while(temp!=null && i<index-1)
		{
			temp=temp.next;
			i++;
		}
		
		if(temp==null)
		{
			System.out.println("Not Valid index");
			return head;
		}
		else if(temp.next==null)
		{
			temp.next=ptr;
			ptr.preq=temp;
			ptr.next=null;
			return head;
		}
		
		else
		{
			ptr.next=temp.next;
			ptr.preq=temp;
			temp.next=ptr;
			return head;
		}
    }
	Node  DeleteNode(Node head,int index)
	{
		Node temp=new Node();
		Node ptr=new Node();
		temp=head;
		ptr=head.next;
		if(index<0)
		{
			System.out.println("Insert Correct Index");
		}
		if(index==0)
		{
			head=head.next;
			head.preq=null;
		}
		int i=0;
	   while(temp!=null &&i<index-1)
	   {
		   temp=temp.next;
		   ptr=ptr.next;
		   i++;
	   }
	   if(temp.next==null)
	   {
		   System.out.println("Out of Index");
		   return head;
	   }
	   else
	   {
		   temp.next=ptr.next;
		   ptr.preq=temp;
		   return head;
	   }
			
	}
	public static void main(String[] args)
	{
		LAB4 obj=new LAB4();
		Node head=new Node();
		Node second=new Node();
		Node third=new Node();
		Node four=new Node();
		head.data=45;
		head.preq=null;
		head.next=second;
		second.data=40;
	   second.preq=head;
		second.next=third;
		third.data=85;
		third.preq=second;
		third.next=four;
		four.data=95;
		four.preq=third;
		four.next=null;
		System.out.println("Before insertion");
		obj.Traverse(head);
		System.out.println("After Insertion");
		head=obj.InsertNode(head,2,90);
		
		obj.Traverse(head);
		System.out.println("After Deletetion");
		head=obj.DeleteNode(head,3);
		obj.Traverse(head);
		
	}
}

*/

   //  Circular Linked List
   
   public class LAB4
   {
	   static class Node
	   {
		   int data;
		   Node next;
	   }
	   void Traverse(Node head)
	   {
		   Node temp=new Node();
		   temp=head;
		   do
		   {
			   System.out.println(temp.data);
			   temp=temp.next;;
		   }
		   while(temp!=head);
	   }
	   
	   Node InsertNode(Node head,int index,int data)
	   {
		   Node temp=new Node();
		   Node ptr=new Node();
		   ptr.data=data;
		   temp=head;
		   if(index==0)
		   {
			   if(head==null)
			   {
				   ptr.next=head;
				   head=ptr;
			    return head;
			   }
			   else{
			     while(temp.next!=head)
				 {
					 temp=temp.next;
			     }
				 ptr.next=head;
				 temp.next=ptr;
				 head=ptr;
				 return head;
			   }
		   }
		   
		   int i=0;
            while(temp.next!=head &&i<index-1)
            {
             temp=temp.next;
             i++;
            }	
			
			if(i!=index-1)
			{
				System.out.println("Out of Bound");
				return head;
			}
			if(temp.next==head)
			{
				ptr.next=head;
				temp.next=ptr;
				head=ptr;
				return head;
			}
			else
			{
				ptr.next=temp.next;
				temp.next=ptr;
				return head;
			}	
	   }
	   public static void main(String[] args)
	   {
		LAB4 obj=new LAB4();
		Node head=new Node();
		Node second=new Node();
		Node third=new Node();
		Node four=new Node();
		head.data=45;
		head.next=second;
		second.data=40;
		second.next=third;
		third.data=85;
		third.next=four;
		four.data=95;
		four.next=head;
		System.out.println("Before insertion");
		obj.Traverse(head);
		System.out.println("After Insertion");
		head=obj.InsertNode(head,1,56);
		obj.Traverse(head);
		   
	   }
   }
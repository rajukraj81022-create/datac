// Traveling Salesman algorithms using Dynamic Programming technique. 

public class LAB11
{
	static int Sales(int arr[][],int row,int m,int n,int count)
	{
		if(count==n)
		{
			return 0;
		}
		 // Base case: if current city has no outgoing paths, stop recursion
        
		 Integer min = null;
		 int total=0;
		 for (int i = 0; i < arr[row].length; i++)
		 {
			 
			 int value=arr[row][i];
			 if(value!=0)
			 {
				 //int total = value + Sales(arr, i, m, n);
				 if(min==null ||value<min)
				 {
					 min=value;
					  total+=min;
					 
					 Sales(arr,i,m,n,count+1);
				 }
			 }
		 }
		 
         return total;
		
	}	
	public static void main(String[] args)
	{
		int [][]arr={
			{0,5,0,6,0,4,0,7},
			{5,0,2,4,3,0,0,0},
			{0,2,0,1,0,0,0,0},
			{6,4,1,0,7,0,0,0},
			{0,3,0,7,0,0,6,4},
			{4,0,0,0,0,0,3,8},
			{0,0,0,0,6,3,0,2},
			{7,0,0,0,4,8,2,0}
		};
		int cost;
		cost=Sales(arr,0,8,8,1);
		System.out.print(cost);
	}
}

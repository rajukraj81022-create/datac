public class Demo1 
{
   public static void main(String[]ags)
   {
    
   } 
}

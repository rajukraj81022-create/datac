public class Employee
{
    int id ;
    int salary;
   String name;
   void set(int Id,int S,String Name )
   {
    this.id=Id;
    this.salary=S;
    this.name=Name;
    
   }
   void get()
   {
    System.out.println("Name is:  "+name+" Salary is: "+salary +" ID is "+id);
   }
 public static void main(String[] args) {
        Employee Emp1=new Employee();
        Emp1.set(101, 235623, "Rohan");
        Emp1.get();
    }
}
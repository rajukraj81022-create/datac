import java.awt.*;
import java.awt.event.*;

public class DemoFrame
{
    DemoFrame()
    {
        Frame f = new Frame("Demo Frame");
        f.setSize(300,300);
        f.setLayout(null);
        f.setVisible(true);

        // To close the window properly
        f.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                f.dispose();
            }
        });
    }

    public static void main(String[] args)
    {
        new DemoFrame();
    }
}
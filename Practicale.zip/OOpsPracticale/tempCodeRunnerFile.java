import java.awt.*;
public class DemoFrame
 {
        DemoFrame()
        {
            Frame f=new Frame();
            f.setSize(300,300);
            f.setVisible(true);
            f.setLayout(null);
        }
         public static void main(String[] args) {
            DemoFrame f=new DemoFrame();
            
        }

}
    


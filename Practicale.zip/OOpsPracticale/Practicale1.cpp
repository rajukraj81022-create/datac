#include<iostream>
using namespace std;
class MyClass
{
    public:
    int x;
    int y;
    MyClass()
    {

    }
    MyClass(int a,int b);
    MyClass operator+(MyClass obj);
    void get();
};
MyClass ::MyClass(int a,int b)
{
    x=a;
    y=b;
}
MyClass MyClass:: operator+(MyClass obj)
{
    MyClass obj1;
    obj1.x=x+obj.x;
    obj1.y=y+obj.y;
    return obj1;
}
void MyClass::get()
{
    cout<<"X is :"<<x<<"  "<<"Y is :"<<y;
}
int main()
{
    MyClass obj1(5,3);
    MyClass obj2(4,3);
    MyClass obj3=obj1+obj2;
    obj3.get();
    return 0;
}
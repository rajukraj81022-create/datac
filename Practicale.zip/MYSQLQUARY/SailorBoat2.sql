create database Sailor_Boat;
use Sailor_Boat;
create table Sailor(
S_id int primary key,
S_name varchar(30) not null,
age int check(age>0),
rating decimal(2,1)
);
insert into Sailor(S_id,S_name,age,rating)
value
(101,"Rohan",32,3.5),
(102,"Mohan",35,5.0),
(103,"Sohan",38,6.0),
(104,"Anil",40,7.5),
(105,"Mukesh",25,9.0);

-- show all Sailor 
select *from Sailor;
-- Create table Boat
create table  Boat(
b_id int primary key,
b_name varchar(30) not null,
colour varchar(40) not null,
rating decimal(2,1)
);
drop table Boat;
-- Insert into  Boat table 
insert into Boat(b_id,b_name,colour,rating)
value
(201,"Grace","Red",6.5),
(202,"Blessed","Blue",7.6),
(203,"evergreen","Black",8.6),
(204,"Titanic","Red",9.6);


-- show all data from Boat table
select *from Boat;

-- Craete table Reservation 
create table Reservation(
R_id int primary key,
S_id int ,
B_id int ,
R_date date,
foreign key(S_id) references Sailor(S_id),
foreign key(B_id) references Boat(B_id)
);
insert into Reservation(R_id,S_id,B_id,R_date)
value
(1011,101,201,"2025-11-07"),
(1012,102,203,"2025-11-08");
-- show all data  from Reservation
select *from Reservation;

-- Alter command 
alter table Sailor add column email varchar(50) not null;

UPDATE Sailor
SET email = 'Rohan@gmail.com'
WHERE S_id = 101;

UPDATE Sailor
SET email = 'Mohan@gmail.com'
WHERE S_id = 102;
UPDATE Sailor
SET email = 'Sohan@gmail.com'
WHERE S_id = 103;
UPDATE Sailor
SET email = 'anil@gmail.com'
WHERE S_id = 104;
UPDATE Sailor
SET email = 'Mukesh@gmail.com'
WHERE S_id = 105;
select *from Sailor;

select *from Boat;

alter table Boat add column salary int not null; 
update Boat set Salary=20000 where B_id=201;
update Boat set Salary=30000 where B_id=202;
update Boat set Salary=10000 where B_id=203;
update Boat set Salary=15000 where B_id=204;
select *from Boat;
--   Some clauses 
ALTER TABLE Boat 
change COLUMN Salary Price int ;

select *from Sailor where S_id =101 ;
select colour from Boat group by colour  ;
select *from Boat order by Price asc;
select *from Boat order by Price DESC;

select *from Sailor limit 2;
-- Having Clauses
select Colour from Boat 
group by Colour having avg(Price>=15000);


-- Agggregate Function 
select count(*)  as TotalBoat from Boat;
select sum(Price) as ToatalPrice from Boat;
select avg(Price) as AvaragePrice from Boat;
select min(price) from Boat;
select max(price) from Boat;

-- Airthmatic operator 
select age from Sailor;
update  Sailor set age=age+2 where S_id=101;
select *from Sailor;
select b_name from Boat where Price>=15000;

select *from Boat where Price between 15000 and 30000;

select S_name from Sailor where S_name like 'A%';
select S_name from Sailor where S_name like '%A';   -- this give the A prsent in last 
select S_name from Sailor where S_name like '___a%';

alter table Sailor add column city varchar(40) not null;
update  Sailor set city="Banglore" where S_id=101;
update  Sailor set city="Patna " where S_id=102;
update  Sailor set city="Gaya" where S_id=103;
update  Sailor set city="Banglore" where S_id=104;
update  Sailor set city="Jaipur" where S_id=105;

select *from Sailor ;

select  *from Reservation;
select city from Sailor group by city;
-- insert into Sailor table 
insert into Sailor(S_id,S_name,age,rating,email,city)
value
(106,"Suhani",32,6.8,"ABGD@GMAIL.COM","Ajmer"),
(107,"Raj",35,6.8,"AhGD@GMAIL.COM","Kota"),
(108,"Rahul",22,8.9,"AtGD@GMAIL.COM","Bodghgaya"),
(109,"Rohan",30,9.8,"ABfg@GMAIL.COM","Gaya");
-- Insert into Boat table 
INSERT INTO Boat (b_id, b_name, Price, colour, rating) VALUES
(205, 'SpeedStar', 1500, 'Red', 4.5),
(206, 'BlueWave', 1800, 'Blue', 4.0),
(207, 'SeaQueen', 2000, 'Green', 4.2),
(208, 'RiverKing', 1300, 'Red', 3.8),
(209, 'OceanPro', 2200, 'Yellow', 4.7);
-- insert into Resrvation 
INSERT INTO Reservation (R_id, S_id, B_id, R_date) VALUES
(1013, 103, 203, '2025-01-14'),
(1014, 101, 201, '2025-02-01'),   -- S_id 101 repeated, B_id 201 repeated
(1015, 102, 202, '2025-02-05'),   -- S_id 102 repeated, B_id 202 repeated
(1016, 104, 203, '2025-02-08'),   -- B_id 203 repeated
(1017, 105, 204, '2025-02-10');
select *from Reservation;

-- INNER JOIN QUESTIONS
-- 1) List Sailor name, Boat name, and reservation date
select S.S_name ,B.b_name, R.R_date 
from Sailor S
 inner join Reservation R 
on S.S_id=R.S_id
 inner join Boat B on R.b_id=B.b_id;

-- Show only sailors who reserved a Red boat
select S.S_id, S.S_name,B.Colour from Sailor S 
join Reservation R on S.S_id=R.S_id 
join Boat B on R.b_id=B.b_id
where B.Colour="Red";

-- Second method 
SELECT s.S_id,s.S_name, b.colour,b.B_name,b.B_id
FROM Sailor s
INNER JOIN Reservation r ON s.S_id = r.S_id
INNER JOIN Boat b ON r.B_id = b.B_id
WHERE b.colour = 'Red';

-- 3) Show sailor name, boat colour, and price
select S.S_name ,B.Colour,B.Price from Sailor S
inner join Reservation R on S.s_id=R.S_id
inner join Boat B on B.b_id=R.b_id;

-- 4) Find all sailors who reserved boats priced more than 15000

select S.S_name ,B.b_id from Sailor S
inner join Reservation R on S.s_id=R.S_id
inner join Boat B on B.b_id=R.b_id
where B.Price>15000;

-- 2. LEFT JOIN QUESTIONS
 -- 5) Show all sailors and reservation details (including those with no reservations)

SELECT s.S_name, r.R_id, r.B_id
FROM Sailor s
LEFT JOIN Reservation r ON s.S_id = r.S_id;


-- 6) Show all sailors and boat names they reserved (NULL if no boat)
select S.S_name, B.b_name from Sailor S
 left join Reservation R on S.S_id=R.S_id
 left join  Boat B on B.b_id=R.b_id;



-- 3. RIGHT JOIN QUESTIONS
-- 7) Show all boats and sailors who reserved them

select B.b_name,B.b_id,B.Colour,S.S_id,S.S_name from Sailor S
Right join Reservation R on R.S_id=S.S_id
right join Boat B on B.b_id=R.b_id;

-- 8) Show boats even if no sailor has reserved them
select B.b_id,B.b_name,R.S_id from Boat B
left join Reservation R on R.b_id=B.b_id; 

-- 4. FULL OUTER JOIN (MySQL alternative using UNION)
-- 9) Show all sailors and all reservations (even unmatched)
select S.S_name,S.S_id,R.R_id from Sailor S 
left join Reservation R  on S.S_id=R.S_id
union
select S.S_name,S.S_id,R.R_id from Sailor S
right join Reservation R on R.S_id=R.S_id;

-- 5. CROSS JOIN QUESTIONS
-- 10) Display every sailor with every boat
SELECT s.S_name, b.b_name
FROM Sailor s
CROSS JOIN Boat b;
-- 6. ADVANCED JOIN QUESTIONS
-- 11) Find sailors who reserved more than one boat

select S.S_name ,count(R.b_id)from Sailor S
join Reservation R on R.S_id=S.S_id
group by R.S_id having count(R.b_id)>1;

-- 12) Show each colour of boat reserved by each sailor
  SELECT s.S_name, b.colour
FROM Sailor s
JOIN Reservation r ON s.S_id = r.S_id
JOIN Boat b ON r.B_id = b.B_id
group by s.S_name, b.colour;

-- 13) Find sailors who reserved Red AND Blue boats

select distinct S.S_name ,B.Colour,B.b_id from Sailor S 
join Reservation R on R.S_id=S.S_id
join Boat B on B.b_id=R.b_id
where B.Colour in('Red','Blue');

-- 14) List sailors who never reserved any boat
select  S.S_name,S.S_id from Sailor S
left join Reservation R on S.S_id=R.S_id
where R.R_id is null;

-- 16) Show sailors from 'Gaya' who reserved any boat
select S.S_name ,S.S_id ,B.b_name from Sailor S
join Reservation R on R.S_id=S.S_id
join Boat B on B.b_id=R.b_id
where S.city ="Gaya";

-- 17) Show the total price of all boats reserved by each sailor
select S.S_name,sum(B.Price) as TotalPrice from Sailor S
join Reservation R on R.S_id=S.S_id
join Boat B on B.b_id=R.b_id
group by S.S_name;

-- 1. List sailors who reserved a Red boat (Nested Subquery)
select S_name,S_id from Sailor where 
S_id in (select S_id from Reservation where 
b_id in (select  b_id from Boat where Colour="Red"));  

-- 2. List boats that were never reserved
select b_name,b_id from Boat
where b_id not in(select b_id from Reservation);

-- 3. List sailors who never reserved any boat

select S_id,S_name from  Sailor 
where S_id not in (select S_id from Reservation );

-- 4. List sailors who reserved more than one boat
select S_name ,S_id from Sailor 
where S_id in (select S_id from Reservation 
group by S_id having count(b_id)>1);


-- 5. List all Red boats reserved by sailor “Rohan”

select b_id,b_name from Boat
where b_id in(select b_id from Reservation
where S_id in(select S_id from Sailor where S_name="Rohan" ))and Colour="Red" ;

-- 6. Show Sailor name & city who reserved boats priced more than 15000

select S_name,City from Sailor 
where S_id in (select S_id from Reservation
where b_id in(select b_id from Boat
where Price>15000));

-- 7. Show boat name reserved after 2025-01-01

select b_name,b_name from Boat
where b_id in(select b_id from Reservation where
R_date>"2025-01-01");


-- 8. Show names of sailors who reserved Titanic
select S_name,S_id from Sailor 
where S_id in (select S_id from Reservation 
where b_id in(select b_id from Boat 
where b_name="Titanic")
);


-- 9. List sailors from “Gaya” who reserved any boat

select S_id,S_name from Sailor 
where City="Gaya" and S_id in (select S_id from Reservation );














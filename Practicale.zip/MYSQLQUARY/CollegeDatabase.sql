create database college;
use college;
CREATE TABLE DEPARTMENT (
    Department_ID INT PRIMARY KEY,
    Department_Name VARCHAR(50) NOT NULL
);
CREATE TABLE COURSE_OFFERED (
    Course_Code VARCHAR(10) PRIMARY KEY,
    Course_Name VARCHAR(50) NOT NULL,
    Course_Credits INT CHECK (Course_Credits > 0),
    Department_ID INT,
    FOREIGN KEY (Department_ID) REFERENCES DEPARTMENT(Department_ID)
);
CREATE TABLE STUDENT (
    Student_ID INT PRIMARY KEY,
    Name VARCHAR(50) NOT NULL,
    DoB DATE,
    Gender CHAR(1) CHECK (Gender IN ('M','F')),
    Department_ID INT,
    FOREIGN KEY (Department_ID) REFERENCES DEPARTMENT(Department_ID)
);
CREATE TABLE COURSE_REGISTERED (
    Course_Code VARCHAR(10),
    Student_ID INT,
    PRIMARY KEY (Course_Code, Student_ID),
    FOREIGN KEY (Course_Code) REFERENCES COURSE_OFFERED(Course_Code),
    FOREIGN KEY (Student_ID) REFERENCES STUDENT(Student_ID)
);
INSERT INTO DEPARTMENT VALUES
(1, 'Computer Science'),
(2, 'Mechanical'),
(3, 'Electrical'),
(4, 'Civil'),
(5, 'Electronics'),
(6, 'IT'),
(7, 'Biotech'),
(8, 'Chemical'),
(9, 'Mathematics'),
(10, 'Physics');
INSERT INTO COURSE_OFFERED VALUES
('CS101','DBMS',4,1),
('CS102','OOP',3,1),
('ME101','Thermodynamics',3,2),
('EE101','Circuits',4,3),
('CE101','Structures',3,4),
('EC101','Microprocessors',4,5),
('IT101','Networking',3,6),
('BT101','Genetics',3,7),
('CH101','Organic Chemistry',4,8),
('MA101','Calculus',3,9);
INSERT INTO STUDENT VALUES
(1,'Ravi','2003-01-01','M',1),
(2,'Anita','2002-07-12','F',2),
(3,'Ramesh','2001-04-22','M',1),
(4,'Sita','2003-02-18','F',3),
(5,'Amit','2002-10-09','M',4),
(6,'Neha','2003-09-29','F',5),
(7,'Arjun','2001-12-10','M',6),
(8,'Priya','2003-08-17','F',1),
(9,'Rahul','2002-06-21','M',3),
(10,'Sneha','2003-11-11','F',2);
INSERT INTO COURSE_REGISTERED VALUES
('CS101',1),
('CS102',1),
('CS101',3),
('ME101',2),
('EE101',4),
('CE101',5),
('EC101',6),
('IT101',7),
('CS101',8),
('MA101',9);

/*Q2   */

alter table COURSE_REGISTERED add column Course_Reg_Date date;
select *from COURSE_REGISTERED;
/*Develop a SQL query to find the total number of credits of each department.*/
select Department_Name, sum(Course_Credits) from DEPARTMENT D join COURSE_OFFERED C
on D.Department_ID=C.Department_ID group by Department_Name;

/*Develop a SQL query to find the second-largest department on student strength.*/

select Department_Name,Department_ID,count(Student_ID) from  DEPARTMENT D join STUDENT S
on D.Department_ID=S.Department_ID group by Department_Name ;

SELECT Department_ID, COUNT(*) AS Student_Count
FROM STUDENT
GROUP BY Department_ID
ORDER BY Student_Count DESC limit 1 offset 1;
/* Create a SQL Natural Join between DEPARTMENT and STUDENT tables.
*/
select *from DEPARTMENT natural join STUDENT;







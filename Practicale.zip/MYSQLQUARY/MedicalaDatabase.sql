create database Medical;
use Medical;
create table Doctor
( Did int primary key,
DFirst varchar(50) not null,
Middle varchar(50),
DLast varchar(50)
);  
alter table Doctor add Specilazation varchar(50) not null;
alter table Doctor add Qualification varchar(50) not null;
select *from Doctor ;
INSERT INTO Doctor (Did, DFirst, Middle, DLast, Specilazation, Qualification) VALUES
(101, 'Rajesh', 'Kumar', 'Sharma', 'Cardiologist', 'MBBS, MD'),
(102, 'Anita', 'Devi', 'Verma', 'Neurologist', 'MBBS, DM'),
(103, 'Rohit', 'Singh', 'Patel', 'Orthopedic', 'MBBS, MS'),
(104, 'Sneha', 'Rani', 'Gupta', 'Dermatologist', 'MBBS, MD'),
(105, 'Amit', 'Kumar', 'Sinha', 'Pediatrician', 'MBBS, DCH'),
(106, 'Pooja', 'Kumari', 'Mehta', 'Gynecologist', 'MBBS, MS'),
(107, 'Vikas', 'Ramesh', 'Nair', 'Radiologist', 'MBBS, MD');
select *from Doctor ;

create table Patient
(
PID int primary key not null,
Pname varchar(50) not null,
Age int check(Age>0) ,
Locality varchar(50)  not null,
city varchar(50) not null
);
INSERT INTO Patient (PID, Pname, Age, Locality, City) VALUES
(201, 'Ravi Kumar', 35, 'Rajendra Nagar', 'Patna'),
(202, 'Neha Sharma', 28, 'Banjara Hills', 'Hyderabad'),
(203, 'Amit Verma', 42, 'Andheri West', 'Mumbai'),
(204, 'Pooja Singh', 31, 'Civil Lines', 'Delhi'),
(205, 'Vikas Patel', 50, 'Maninagar', 'Ahmedabad'),
(206, 'Sneha Gupta', 26, 'Salt Lake', 'Kolkata'),
(207, 'Arjun Mehta', 39, 'Anna Nagar', 'Chennai');
create table Treatment 
(
Did int,
PID int,
foreign key(Did) references Doctor(Did),
foreign key(PID) references Patient(PID),
treat varchar(50)
);
INSERT INTO Treatment (Did, PID, treat) VALUES
-- Doctor 101 has 4 cases
(101, 201, 'Heart Checkup'),
(101, 202, 'Blood Pressure'),
(101, 205, 'Cardiac Pain'),
(101, 206, 'Routine Heart Test'),

-- Doctor 102 has 2 cases
(102, 203, 'Migraine Treatment'),
(102, 207, 'Headache Relief'),

-- Doctor 103 has 1 case
(103, 204, 'Fracture Recovery');

create table Medicine
(
   Mcode int Primary key not null,
Price int not null,
Quantity int not  null
);
INSERT INTO Medicine (Mcode, Price, Quantity) VALUES
(301, 120, 50),     -- Paracetamol
(302, 250, 30),     -- Amoxicillin
(303, 80, 100),     -- Cough Syrup
(304, 500, 20),     -- Insulin
(305, 60, 200),     -- Vitamin C Tablets
(306, 900, 10),     -- Antibiotic Injection
(307, 150, 75);  

create table Bill
(
  PID int,
  Mcode int,
  foreign key(PID) references Patient(PID),
  foreign key(Mcode) references Medicine(Mcode)
  );
  INSERT INTO Bill (PID, Mcode) VALUES
(201, 301),   -- Patient 101 buys Paracetamol
(202, 302),   -- Patient 102 buys Amoxicillin
(203, 303),   -- Patient 103 buys Cough Syrup
(204, 304),   -- Patient 104 buys Insulin
(205, 305),   -- Patient 105 buys Vitamin C
(206, 306),   -- Patient 106 buys Antibiotic Injection
(207, 307),   -- Patient 107 buys Pain Relief Gel
(201, 302),   -- Patient 101 also buys Amoxicillin
(203, 301);  
  
-- Develop an SQL query to RENAME PATIENT table as CASE.
alter table Patient rename Case;



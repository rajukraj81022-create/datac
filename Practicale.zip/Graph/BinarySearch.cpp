#include<iostream>
using namespace std;
int BinarySearch(int arr[],int n,int Target)
{
    int low=0;
    int high=n;
    while(low<=high)
    {
        
        int mid=(low+high)/2;
        if(arr[mid]==Target)
        {
            return mid;
        }
        else if(arr[mid]>Target)
        {
            low=mid+1;
        }
        else{
            high=mid;
        }

    }
}
int main()
{
    int arr[]={2,3,6,10,12,15,17};
    int n=sizeof(arr)/sizeof(arr[0]);
    int index=BinarySearch(arr,n,10);
    if(index>0)
    {
        cout<<" index is :"<<index;
    }
    else{
        cout<<"elment not fount ";
    }
    return 0;
}
#include<iostream>
#include<string>
using namespace std;
class Stack
{
    public:
    int size=12;
    int top=-1;
    int *arr;

int Operator(char ch)
{
    if(ch=='+'||ch=='-'||ch=='*'||ch=='/')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void Push(int data)
{
    if(top==size-1)
    {
        cout<<"Stack is Full\n";
    }
    else
    {
        top++;
        arr[top]=data;
    }
}
int Pop()
{
    if(top==-1)
    {
        cout<<"Stack is Under Flow \n";
    }
    else
    {
        int val=arr[top];
        top--;
        return val;

    }
}
int Evalution(string str)
{
    int Result=0;
    for(int i=0;i<str.length();i++)
    {
         if(Operator(str[i])==0)
         {
            Push(str[i]-'0');
         }
         else
         {
            int val1=Pop();
            int val2=Pop();
            switch (str[i])
            {
                case '+':
                {
                    Result=val1+val2;
                    break;
                }
                case '-':
                {
                    Result=val2-val1;
                    break;
                }
                case '*':
                {
                    Result=val1*val2;
                    break;
                }
                case '/':
                {
                    Result=val2/val1;
                    break;
                }
            }
            Push(Result);
         
        
         }
    }
    int val3=Pop();
    return val3;
}
};
int main()
{
    Stack obj;
    obj.size=14;
    obj.arr=new int [obj.size];
    string str="231*+9-";
cout<<obj.Evalution(str);
}



#include<iostream>
using namespace std;
class Queue
{
    public:
    int size;
    int Front;
    int Rear;
    int *arr;
    Queue()
    {
        size=13;
        Front=-1;
        Rear=-1;
        arr=new int[size];
    }
    int IsEmpty()
    {
        if(Front==-1&&Rear==-1)
        {
            return 1;
        }
        else{
            return 0;
        }
    }
    int IsFull()
    {
        if(Rear==size-1)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    void Push(int data)
    {
        if(IsFull()==1)
        {
            cout<<"Queue is Full\n";
        }
        else
        {
            Rear++;
            arr[Rear]=data;
            if(Front==-1)
            {
                Front++;
            }
        }
    }
    int Pop()
    {
        if(IsEmpty()==1)
        {
            cout<<"Queue is Under Flow\n";
            return -1;
        }
        else{
            int val=arr[Front];
            Front++;
            return val;
        }
    }
    void Traversal()
    {
        for(int i=Front;i<=Rear;i++)
        {
            cout<<arr[i]<<endl;
        }
    }
};
int main()
{
    Queue obj;
    cout<<obj.IsEmpty()<<endl;
    cout<<obj.IsFull()<<endl;
    obj.Push(34);
    obj.Push(21);
    obj.Push(26);
     obj.Push(61);
      obj.Push(31);
      obj.Traversal();
      obj.Pop();
      obj.Pop();
      cout<<"After Pop Operation\n";
      obj.Traversal();
}
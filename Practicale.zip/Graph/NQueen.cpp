#include <iostream>
using namespace std;

#define N 4  // You can change N (e.g., 8 for 8-Queen)

// Function to check if a queen can be placed safely
bool IsSafe(int board[N][N], int row, int col)
{
    // Check column
    for (int i = 0; i < row; i++)
        if (board[i][col] == 1)
            return false;

    // Check upper-left diagonal
    for (int i = row, j = col; i >= 0 && j >= 0; i--, j--)
        if (board[i][j] == 1)
            return false;

    // Check upper-right diagonal
    for (int i = row, j = col; i >= 0 && j < N; i--, j++)
        if (board[i][j] == 1)
            return false;

    return true;
}

// Function to solve N-Queen using backtracking
bool NQueen(int board[N][N], int row)
{
    // If all queens are placed
    if (row == N)
        return true;

    for (int col = 0; col < N; col++)
    {
        if (IsSafe(board, row, col))
        {
            board[row][col] = 1;

            if (NQueen(board, row + 1))
                return true;

            // Backtrack
            board[row][col] = 0;
        }
    }
    return false;
}

// Function to print the board
void PrintBoard(int board[N][N])
{
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
            cout << board[i][j] << " ";
        cout << endl;
    }
}

// Main function
int main()
{
    int board[N][N] = {0};

    if (NQueen(board, 0))
        PrintBoard(board);
    else
        cout << "No solution exists";

    return 0;
}

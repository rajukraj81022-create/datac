#include<iostream>
using namespace std;

int main()
{
    int Max = 20;
    int weight[] = {3,5,7,1,4,1};
    int Profit[] = {5,15,7,6,18,3};
    int n = sizeof(weight)/sizeof(weight[0]);

    float Ratio[n];

    for(int i=0;i<n;i++)
    {
        Ratio[i] = (float)Profit[i] / weight[i];   // ✅ float division
    }

    for(int i=0;i<n-1;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {
            if(Ratio[j+1] >= Ratio[j])
            {
                float tempR = Ratio[j+1];          // ✅ float
                Ratio[j+1] = Ratio[j];
                Ratio[j] = tempR;

                int tempP = Profit[j+1];
                Profit[j+1] = Profit[j];
                Profit[j] = tempP;

                int tempW = weight[j+1];
                weight[j+1] = weight[j];
                weight[j] = tempW;
            }
        }
    }

    double sum = 0;
    int i = 0;

    while(Max > 0 && i < n)
    {
        if(Max > weight[i])
        {
            sum += Profit[i];
            Max -= weight[i];
        }
        else
        {
            sum += Max * ((double)Profit[i] / weight[i]); // ✅ float fraction
            Max = 0;
        }
        i++;
    }

    cout << "Maximum Profit is : " << sum;
}

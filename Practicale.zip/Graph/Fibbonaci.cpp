#include<iostream>
using namespace std;
int fibbonaci(int arr[],int n,int x)
{
    int fib1=1;
    int fib2=0;
    int fib=fib1+fib2;
    while(fib<n)
    {
        fib=fib1+fib2;
        fib2=fib1;
        fib1=fib;
    }
    int offset=-1;
    while(fib>1)
    {
        int i=min(offset+fib2,n-1);
        if(arr[i]<x)
        {
            fib=fib1;
            fib1=fib2;
            fib2=fib-fib1;
            offset=i;
        }
       else if(arr[i]>x)
        {
            fib=fib2;
            fib1=fib1-fib2;
            fib2=fib-fib1;
        }
        else
        {
            return i;
        }
    }
    if(fib1==1&&arr[offset+1]==x)
    {
        return offset+1;
    }
    return -1;
} 
int main()
{
    int arr[]={2,3,6,10,12,15,17};
    int n=sizeof(arr)/sizeof(arr[0]);
    int index=fibbonaci(arr,n,10);
    if(index>0)
    {
        cout<<" index is :"<<index;
    }
    else{
        cout<<"elment not fount ";
    }
    return 0;
}
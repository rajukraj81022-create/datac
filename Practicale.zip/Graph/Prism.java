public class Prism {

    public static void main(String[]args)
    {
        int v=5;
        int []visited=new int[v];
        int a[][]=
     {
        {0, 2, 0, 6, 0},
         {2, 0, 3, 8, 5},
         {0, 3, 0, 0, 7},
        {6, 8, 0, 0, 9},
         {0, 5, 7, 9, 0}
     };
    int edge =0;
    visited[0]=1;
    int sum=0;
    while(edge<v-1)
    {
        int min=999;
        int x=0;
        int y=0;
        for(int i=0;i<5;i++)
        {
            if(visited[i]==1)
            {
                for(int j=0;j<v;j++)
                {
                    if(visited[j]==0 && a[i][j]!=0)
                    {
                        if(a[i][j]<min)
                        {
                            x=i;
                            y=j;
                            min=a[i][j];
                         }
                    }
                }
            }

        }
        System.out.println(x +"-->"+y+" ="+a[x][y]);
        edge++;
        visited[y]=1;
        sum+=a[x][y];

    }
    System.out.println("Total Coat is ="+sum);

    }
    
}

public class DFS {
    int visited[]={0,0,0,0,0,0,0};
    void DeptFS(int [][]a,int i)
    {

        System.out.print(" "+i+" ");
                visited[i]=1;
        for(int j=0;j<7;j++)
        {
            if(a[i][j]==1&&visited[j]==0)
            {
                DeptFS(a, j);
            }
        }
    }
    public static void main(String[]args)
    {
        DFS obj=new DFS();
        int i=0;
        int a[][]={
            {0,1,1,1,0,0,0},
            {1,0,0,1,0,0,0},
            {1,1,0,1,1,0,0},
            {1,0,1,0,1,0,0},
            {0,0,1,1,0,1,1},
            {0,0,0,0,1,0,0},
            {0,0,0,0,1,0,0}
        };
        obj.DeptFS(a,i);
    }
    
}

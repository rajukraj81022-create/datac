#include<iostream>
using namespace std;
class Circular
{
    public:
    int size;
    int Front;
    int Rear;
    int Count;
    int *arr;
    Circular()
    {
        size=6;
        Front=0;
        Rear=0;
        Count=0;
        arr=new int[size];
    }
    int IsEmpty()
    {
        if(Count==0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    int IsFull()
    {
        if(Count==size-1)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    void Push(int data)
    {
        if(IsFull()==1)
        {
            cout<<"Queue is Over Flow\n";
        }
        else
        {
            arr[Rear]=data;
            Rear=(Rear+1)%size;
            Count++;
        }
    }
    int Pop()
    {
        if(IsEmpty()==1)
        {
            cout<<"Queue is under flow\n";
        }
        else
        {
            int val=arr[Front];
            Front=(Front+1)%size;
            Count--;
            return val;
    }
}
void Traversal()
{
    for(int i=Front;i<Rear;i++)
    {
        cout<<arr[i]<<endl;
    }
}
};
int main()
{
    Circular obj;
    cout<<obj.IsEmpty()<<endl;
    cout<<obj.IsFull()<<endl;
    obj.Push(34);
    obj.Push(21);
    obj.Push(26);
     obj.Push(61);
      obj.Push(31);
     obj.Traversal();
      obj.Pop();
      obj.Pop();
      cout<<"After Pop Operation\n";
      obj.Traversal();
}
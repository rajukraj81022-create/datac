#include<iostream>
using namespace std;
class Stack
{
    public:
    int size;
    int top=-1;
    int *arr;
};
int IsEmpty(Stack *node)
{
    if(node->top==-1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
int IsFull(Stack *node)
{
    if(node->top==node->size-1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void Push(Stack *node,int data)
{
    if(IsFull(node)==1)
    {
        cout<<"Stack is over Flow\n";
    }
    else
    {
        node->top++;
        node->arr[node->top]=data;
    }
}
int Pop(Stack *node)
{
    if(IsEmpty(node)==1)
    {
        cout<<"Stack is Under Flow \n";
        return -1;
    }
    else
    {
        int val=node->arr[node->top];
        node->top--;
        return val;
    }
}
void Traversal(Stack *node)
{
    for(int i=node->top;i>=0;i--)
    {
        cout<<node->arr[i]<<endl;
    }
}
int main()
{
    Stack *obj=new Stack();
    obj->size=12;
    obj->arr=new int[obj->size];
    cout<<IsEmpty(obj)<<endl;
    cout<<IsFull(obj)<<endl;
    Push(obj,23);
    Push(obj,33);
    Push(obj,43);
    Push(obj,63);
    Push(obj,13);
    Push(obj,53);
    Traversal(obj);
    cout<<Pop(obj)<<endl;
    cout<<Pop(obj)<<endl;
    cout<<"Aftre Pop Oparetion\n";
    Traversal(obj);
    return 0;

}
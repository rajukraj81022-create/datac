#include<iostream>
using namespace std;
int Sort(int arr[],int low,int mid,int high)
{
    int Copy[high-low+1];
    int x=0;
    int indx1=low;
    int indx2=mid+1;
    while(indx1<=mid &&indx2<=high)
    {
        if(arr[indx1]<=arr[indx2])
        {
            Copy[x++]=arr[indx1++];
        }
        else
        {
            Copy[x++]=arr[indx2++];
        }
    }
    while(indx1<=mid)
    {
        Copy[x++]=arr[indx1++];
    }
    while(indx2<=high)
    {
        Copy[x++]=arr[indx2++];
    }
      for(int i = 0; i < x; i++)
        arr[low + i] = Copy[i];
}
void Display(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
}
void MergedSort(int arr[],int low ,int high)
{
    if(low>=high)
    {
        return;
    }
    int mid=(low+high)/2;
    MergedSort(arr,low,mid);
    MergedSort(arr,mid+1,high);
    Sort(arr,low,mid,high);
}
int main()
{
    int arr[]={1,32,2,4,6,9};
    int n=sizeof(arr)/sizeof(arr[0]);
    MergedSort(arr,0,n-1);
    Display(arr,n);
}
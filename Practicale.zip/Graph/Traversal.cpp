#include<iostream>
using namespace std;
int visited[]={0,0,0,0};
int Cost=0;

int Traversal(int arr[4][4],int Row)
{
    int next=-1;
    int mincost=999;
    visited[Row]=1;
    for(int i=0;i<4;i++)
    {
        if(mincost>=arr[Row][i]&&arr[Row][i]!=0&&visited[i]==0)
        {
                mincost=arr[Row][i];
                next=i;
       }
    }
    if(next!=-1)
    {
        Cost+=mincost;
        Traversal(arr,next);
    }

}
int main()
{
   int cost[4][4] = {
    {0, 10, 15, 20},
    {10, 0, 35, 25},
    {15, 35, 0, 30},
    {20, 25, 30, 0}
};
Traversal(cost,0);
cout<<Cost;
}

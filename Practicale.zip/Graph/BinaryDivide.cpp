#include<iostream>
using namespace std;
int Binary(int arr[],int Low,int high,int Target)
{
    if(Low>=high)
    {
        return -1;
    }
    int mid=(Low+high)/2;
     if(arr[mid]>Target)
    {
        Binary(arr,Low,mid,Target);
    }
    else if(arr[mid]<Target)
    {
        Binary(arr,mid+1,high,Target);
    }
    else
    {
        return mid;
    }
}
int main()
{
    int arr[]={12,23,24,27,30,32};
    int n=sizeof(arr)/sizeof(arr[0]);
  int index=Binary(arr,0,n,30);
  if(index>=0)
  {
    cout<<"Index is :"<<index;
  }
  else{
    cout<<"Element not Fount \n";
  }
  return 0;
}

/*

// FIRST METHOD 
class  BFSGraph
{
    static class Queue
    {
        int []arr;
        int Rear;
        int Front ;
        int size;
        Queue()
        {
            this.Rear=0;
            this.Front=0;
            this.size=100;
            arr=new int[size];
        }
    }
    int IsEmpty(Queue node)
    {
        if(node.Rear==node.Front)
        {
            return 1;
        }
        else{
            return 0;
        }
    }
    int IsFull(Queue node)
    {
        if(node.Rear!=node.size-1)
        {
            return 1;
        }
        else{
            return 0;
        }
    }
    int Deque(Queue node)
    {
        if(IsEmpty(node)==1)
        {
            System.out.println("Queue is full");
            return 1;
        }
        else{
            int val=node.arr[node.Front];
            node.Front++;
            return val;
        }
    }
    void Inque(Queue node,int data)
    {
        node.arr[node.Rear]=data;
        node.Rear++;

    }

    public static void main(String[]args)
    {
        BFSGraph obj=new BFSGraph();
        Queue temp=new Queue();
        int i=0;
        int visited[]={0,0,0,0,0,0,0};
        int a[][]={
            {0,1,1,1,0,0,0},
            {1,0,0,1,0,0,0},
            {1,1,0,1,1,0,0},
            {1,0,1,0,1,0,0},
            {0,0,1,1,0,1,1},
            {0,0,0,0,1,0,0},
            {0,0,0,0,1,0,0}
        };
        System.out.print(i+" ");
        obj.Inque(temp, i);
        visited[i]=1;
        while(obj.IsEmpty(temp)==0)
        {
            int val=obj.Deque(temp);
            
            for(int j=0;j<7;j++)
            {
                if(a[val][j]==1&&visited[j]==0)
                {
                    System.out.print(j+" ");
                    visited[j]=1;
                    obj.Inque(temp, j);
                }

            }

        }

    }
}
*/

// 2nd method 
import java.util.Queue;
import java.util.LinkedList;
class BFSGraph
{
    public static void main(String[]args)
    {
        Queue<Integer> q = new LinkedList<>();
        int i=0;
        int visited[]={0,0,0,0,0,0,0};
        int a[][]={
            {0,1,1,1,0,0,0},
            {1,0,0,1,0,0,0},
            {1,1,0,1,1,0,0},
            {1,0,1,0,1,0,0},
            {0,0,1,1,0,1,1},
            {0,0,0,0,1,0,0},
            {0,0,0,0,1,0,0}
        };
        System.out.print(i+" ");
        q.add(i);
        visited[i]=1;
        while(!q.isEmpty())
        {
            int val=q.remove();
            for(int j=0;j<7;j++)
            {
                if(a[val][j]==1&&visited[j]==0)
                {
                    System.out.print(j);
                    visited[j]=1;
                    q.add(j);
                }
            }
        }


    }
}
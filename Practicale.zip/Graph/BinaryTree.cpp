#include <iostream>
using namespace std;
class Node
{
public:
    int data;
    Node *Left;
    Node *Right;
    Node(int val)
    {
        data = val;
        Left = NULL;
        Right = NULL;
    }
};
Node *Create(Node *Root, int val)
{

    if (Root == NULL)
    {
        Root = new Node(val);
        return Root;
    }
    if (Root->data > val)
    {
        Root->Left = Create(Root->Left, val);
    }
    else
    {
        Root->Right = Create(Root->Right, val);
    }
    return Root;
}
Node *Input(Node *Root)
{
    int data = 0;
    while (true)
    {
        cout << "Enter the Data\n";
        cin >> data;
        if (data == -1)
        {
            break;
        }
        Root = Create(Root, data);
    }
    return Root;
}
void InOrder(Node *Root)
{
    if (Root == NULL)
    {
        return;
    }
    InOrder(Root->Left);
    cout << Root->data << endl;
    InOrder(Root->Right);
}
void PreOrder(Node *Root)
{
    if (Root == NULL)
    {
        return;
    }
    cout << Root->data<<endl;
    PreOrder(Root->Left);
    PreOrder(Root->Right);
}
void PostOrder(Node *Root)
{
    if(Root==NULL)
    {
        return ;
    }
    PostOrder(Root->Left);
    PostOrder(Root->Right);
    cout<<Root->data<<endl;
}

int main()
{
    Node *Root = NULL;
    Root = Input(Root);
    cout << "InOrder Traversal is \n";
    InOrder(Root);
    cout<<"PreOrder Travershal\n";
    PreOrder(Root);
    cout<<"Post Order Travershal\n";
    PostOrder(Root);
    return 0;
}
#include<iostream>
using namespace std;
//#define  N=4;
bool IsSafe(int Board[4][4],int Row,int col)
{
    for(int i=0;i<Row;i++)
    {
        if(Board[i][col]==1)
        {
            return false;
        }
    }
    for(int i=Row,j=col;i>=0&&j>=0;i--,j--)
    {
        if(Board[i][j]==1)
        {
            return false;
        }
    }
    for(int i=Row,j=col;i>=0 &&j<4;i--,j++)
    {
        if(Board[i][j]==1)
        {
            return false;
        }
    }
    return true;
}
bool NQueen(int Board[4][4], int Row)
{
    if(Row==4)
    {
        return true ;
    }
        for(int j=0;j<4;j++)
        {
            if(IsSafe(Board,Row,j))
            {
                Board[Row][j]=1;
            
              if( NQueen(Board,Row+1))
               return true;
               Board[Row][j]=0;
            }
       }
        return false;
}
int main()
{
    int Board[4][4]={0};
    NQueen(Board,0);
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            cout<<Board[i][j]<<" ";
        }
        cout<<"\n";
    }
}
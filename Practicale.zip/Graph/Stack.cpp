#include<iostream>
using namespace std;
int Push(int arr[],int size,int &top,int data)
{
    if(top=size-1)
    {
        return 1;
    }
    else{
        top++;
        arr[top]=data;
    }
}
void Display(int arr[],int top)
{
    for(int i=top;i>=0;i--)
    {
        cout<<arr[i];
    }
}
int main()
{int size=10;
    int arr[size];
    int top=-1;
    Push(arr,size,top,32);
    Push(arr,size,top,32);
    Push(arr,size,top,32);
    Display(arr,top);
}
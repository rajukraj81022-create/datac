#include<iostream>
using namespace std;
class CreateReact
{
    int *width;
    int *height;
    public:
    CreateReact(int a,int b);
    ~CreateReact();
    int area();
};
CreateReact::CreateReact(int a,int b)
{
    width=new int;
    height=new int ;
    *width=a;
    *height=b;
}
int CreateReact::area()
{
    return (*width * *height);
}
CreateReact::~CreateReact()
{
    cout<<"Destructor is called\n";
    delete width;
    delete height;
}
int main()
{
    CreateReact React(3,4);
    cout<<"Area is :"<< React.area()<<endl;

}
#include<iostream>
using namespace std;
class Square;
class CreateReact
{
    int width,height;
    public:
    CreateReact(int ,int);
    int area()
    {
        return width*height;
    }
    void convert(Square obj);

};
class Square
{
    int side;
    public:
    Square(int side)
    {
        this->side=side;
    }
    friend class CreateReact;
};
CreateReact::CreateReact(int a,int b)
{
    height=a;
    width=b;
}
void CreateReact::convert(Square obj)
{
    width=obj.side;
    height=obj.side;
}
int main()
{
    CreateReact React(3,4);
    Square sqr(8);
    cout<<React.area()<<"\n";
    React.convert(sqr);
    cout<<React.area();


}
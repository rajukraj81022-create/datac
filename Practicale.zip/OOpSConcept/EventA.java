import java.awt.*;
import java.awt.event.*;
class EventA extends Frame implements ActionListener
{
    TextField tf;
         EventA()
         {
           tf=new TextField();
            tf.setBounds(60,70,70,60);
            Button b=new Button();
             b.setLabel("click me");
             b.setBounds(70,120,50,40);
             b.addActionListener(this);//passing current instance
             add(b);
             add(tf);
             setSize(300,300);
             setVisible(true);
        
             setLayout(null);
            }
            public void actionPerformed(ActionEvent e){
                tf.setText("Welcome");
            }
public static void main(String[] args)
{
   new EventA();
}
}
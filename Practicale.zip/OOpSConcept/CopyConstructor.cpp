#include<iostream>
using namespace std;
class MyClass
{
    int val;
    int copynumber;
    public:
    MyClass(int i)
    {
        val=i;
        copynumber=0;
    }
    //Copy Constructor 
    MyClass(const MyClass &obj)
    {
        val=obj.val;
        copynumber=obj.copynumber+1;
        cout<<"Inside the copyconstructor\n";
    }
    ~MyClass()
    {
        if(copynumber==0)
        {
            cout<<"Destroying Original\n";
        }
        else
        {
            cout<<"Destroying copy\n"<<copynumber<<"\n";
        }
    }
    int getvalue()
    {
        return val;

    }
};
void display(MyClass obj)
{
    cout<<obj.getvalue()<<"\n";
}
int main()
{
    MyClass obj(10);
    display(obj);
   


}

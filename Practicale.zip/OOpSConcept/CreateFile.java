import java.util.Scanner;
import java.io.*;
class CreateFile
{
    public static void main(String[]args)
    {
        try{
            // File MyFile=new File("Output.txt");
            // if(MyFile.createNewFile())
            // {
            //     System.out.println("File is Created");
            // }
            // else{
            //     System.out.println("File is Already Exist");
            // }
            FileWriter fw=new FileWriter("newFile.txt");
            fw.write("This is Java File  ");
            fw.close();
            System.out.println(("File Written is Succesfully"));

            // File Reading 
            File file = new File("newFile.txt");
            Scanner sc=new Scanner(file);
            while(sc.hasNextLine())
            {
                String data=sc.nextLine();
                System.out.println(data);
            }


        }
        catch(IOException e)
        {
            System.out.println(("Error whilke creating File "));
        }
    }
}
#include<iostream>
using namespace std;
class CreateReact{
    int height;
    int width;
    public:
    int area(void);
    CreateReact(int a,int b);

};
int CreateReact::area(void)
{
    return height*width;
}
CreateReact::CreateReact(int a,int b)
{
    height=a;
    width=b;
}
int main()
{
    CreateReact React(3,4);
    cout<<React.area();

}
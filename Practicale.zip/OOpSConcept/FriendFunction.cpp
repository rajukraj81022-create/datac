/*

#include<iostream>
using namespace std;
class CreateReact
{
    int width,height;
    friend  int area(CreateReact obj);
    public:
    CreateReact(int a,int b);

};
CreateReact::CreateReact(int a,int b)
{
    width=a;
    height=b;
}
int  area(CreateReact obj)
{
    return obj.width*obj.height;
}
int main()
{
    CreateReact React(4,3);
    cout<<area(React);

}
*/

// Create another object using friend function

#include<iostream>
using namespace std;
class CreateReact
{
    int width,height;
    friend CreateReact duplicate(CreateReact temp); 
    public:
    void set(int ,int );
    int area()
    {
        return width*height;
    }
};
void CreateReact::set(int a,int b)
{
    width=a;
    height=b;
}
CreateReact duplicate(CreateReact temp)
{
    CreateReact parm;
    parm.width=temp.width*2;
    parm.height=temp.height*2;
    return parm;
}
int main()
{
    CreateReact React;
    React.set(3,4);
   cout<<React.area()<<"\n";
    cout<<"Area of object B\n";
    CreateReact Reactb=duplicate(React);
    cout<<Reactb.area();

}




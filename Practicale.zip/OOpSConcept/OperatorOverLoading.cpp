#include<iostream>
using namespace std;
class Vector
{
    public:
    int x;
    int y;
    Vector(int ,int );
    Vector operator+(Vector obj);
};
Vector::Vector(int a,int b)
{
    x=a;
    y=b;
}
Vector Vector::operator+(Vector obj)
{
    Vector temp(0,0);
    temp.x=x+obj.x;
    temp.y=y+obj.y;
    return temp;
}
int main()
{
    Vector a(3,4);
    Vector b(2,3);
    Vector c=a+b;
    cout<<c.x<<"   "<<c.y;
}
//  INHeritence 

//Single inheritace 

/*
class Shape
public:   //in java if we not write this Arributes and
          //         function define as Default 
    String color;
	void print(){
	 System.out.print(color);
	}
}
class Reactangle extends Shape{
	
}
public class Class{
   public static void main(String[] args){
     Reactangle obj1=new Reactangle();
	 obj1.color="Green";
	 obj1.print();
   
   }

}
*/

package Tool;
public class cal {

  public  int add(int a,int b)
    {
        return (a*b);
    }
    public static void main(String []args)
    {

    }
}

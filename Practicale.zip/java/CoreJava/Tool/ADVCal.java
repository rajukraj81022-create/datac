package Tool;

public class ADVCal {
    public int Multi(int a,int b)
    {
        return (a*b);
    }
    
}

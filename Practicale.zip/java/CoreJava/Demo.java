import Tool.cal;
public class Demo {
    public static void main(String[]args)
    {
        cal obj =new cal();
        obj.add(3,4);
    }
}

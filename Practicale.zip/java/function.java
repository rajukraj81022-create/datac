
// Bsic code of function 
/*
import java.util.*;
public class function{
	public static void printname(String name)
	{
		System.out.println(name);
		return;
	}
public static void main(String[] args){
 
  Scanner sc =new Scanner(System.in);
  System.out.println("Enter the name: ");
  String f=sc.next();
  printname(f);
   
 }



}

*/

/*

import java.util.*;
public class function{
	public static int sum(int a,int b)
	{
		return (a+b);
	}
  public static void main(String[] args){
	  Scanner sc=new Scanner(System.in);
	  System.out.println("enter the value of a :");
	  int a=sc.nextInt();
	  System.out.println("enter the value of b:");
	  int b=sc.nextInt();
	  int s=sum(a,b);
	  System.out.print(s);
	  



    }
}

*/

//multiply two number by using function 
/*
import java.util.*;
public class function{
     public static int  multiple(int a,int b)
	 {
	    return (a*b);
	 
	 }
   public static void main(String[] args){
    
	Scanner sc=new Scanner(System.in);
	System.out.print("enter the number a:");
	int a=sc.nextInt();
	System.out.print("enter the number b:");
	int b=sc.nextInt();
	int m=multiple(a,b);
	System.out.print(m);
	
	
	}



}

*/

// BASIC CODE OF ARRAY

/*

import java.util.*;
public class function{
  public static void main(String[] args)
  {
	 Scanner sc=new Scanner(System.in);
	 System.out.print("Enter the size of element:");
	 int size=sc.nextInt();
    int arr[]=new int [size];
	
    for(int i=0;i<size;i++)
	{
	 System.out.print("enter the elment:");
	 arr[i]=sc.nextInt();
	}
    for(int i=0;i<size;i++)
	{
	
	   System.out.println(arr[i]); 
	}
  
  }



}

*/
// BASIC CONCEPT OF STRING 
/*
import java.util.*;
public class function{
    public static void main( String[] args){
	  
	  Scanner sc=new Scanner(System.in);
	  System.out.print("ENTER THE NAME :");
	  String name=sc.nextLine();
	  System.out.print(name
	  
	  
	
	
	}




}

*/
/*
import java.util.*;
public class function{
   
   public static void main(String[] args){
	   /*
      String first="Rohit";
	  String last="Raj";
	  //concatenation  Add to string 
	  String name=first+" @ "+last;
	  System.out.println(name);
      // lenght of string 
	  System.out.print(name.length());
	  
	  //char at print each elment of string
	  for(int i=0;i<name.length();i++)
	  {
		  System.out.println(name.charAt(i));
	  }
   
      */
     // COMPAIRE TO STREING EQUAL OR NOT 
	 /*
	  String name1="Rohit";
	  String name2="Ajay";
	  // S1>S2=+ve value
	  //S1==S2=0 
	  //S1<s2=-ve value
	  if(name1.compareTo(name2)==0)
	  {
		  System.out.print("Both are equal ");
	  }
	  else if(name1.compareTo(name2) > 0)
	  {
		  System.out.print("Name1 greter then name2 ");
	  }
	  else{
	     System.out.print("name1 is less than name2");
	  }
   }


}
*/


/*
import java.util.*;
public class function{
   public static void main(String[] args){
	   
	  //substring 
     String sentance="tony is good boy";
	 String name=sentance.substring(0,4);
	 System.out.print(name);
    
   }
// String me hum update nhi kar sakte hai 



}

*/



// String Builder 

/*
import java.util.*;
public class function{
 public static void main(String[] args){
     StringBuilder sb=new StringBuilder("Tony");
	 System.out.println(sb);
	 //char at index 
	 System.out.println(sb.charAt(0));
	 // set char at index
	 sb.setCharAt(2,'m');
	 System.out.println(sb);
	 sb.insert(3,'n');  // insert in any place of String 
	 System.out.println(sb);
	 sb.delete(2,3);
	 System.out.println(sb);
	 System.out.println("After appending");
	 //Append in string (add in last )
	 sb.append(" ");
	 sb.append("i");
	 sb.append("s");
	 System.out.println(sb);
	 
   }




}
*/


//Reverse the String 

/*
import java.util.*;
public class function{
  public static void main(String[] args)
  {
	  StringBuilder sb=new StringBuilder( "Tonny");
	  System.out.println(sb);
	   
	  for(int i=0;i<sb.length()/2;i++)
	  {
		  int front=i;
		  int back=sb.length()-1-i;
		  char frontChar=sb.charAt(front);
		  char backChar=sb.charAt(back);
		  sb.setCharAt(front,backChar);
		  sb.setCharAt(back,frontChar);
	  }
	  System.out.println(sb);
  }



}

*/


// operator 

// Bit Manupulation 

import java.util.*;
public  class function{
   public static void main(String[] args){
   
     int n=5;
	 int pos=1;
	 int bitm=1<<pos;
	 if((bitm & n) == 0)
	 {
		 System.out.println("Bit is Zero");
	 }
	 else
	 {
		 System.out.println("Bit is 1");
	 }
	 
	 // set bit 
     int newNumber=bitm | n; 
     System.out.println(newNumber);	 
	 // clear bit mean 1=0,0=1
	 int poss=2;
	 int bitmask=1<<poss;
	 int notmask=~bitmask;
	 int number= notmask & n;
     System.out.println(number);	 
   }

}	








class Pen{
	String color;
	String type;
	public void Write()
	{
		System.out.println("Writting Somthing");
	}
	public void print()
	{
		System.out.println(this.color);
		
	}
};
public class OOPS{
	public static void main(String[] urgs){
	  Pen pen1=new Pen();
	  pen1.color="Blue";
	  pen1.type="Ball Pen";
	  Pen pen2=new Pen();
	  pen2.color="Black";
	  pen2.type="Gell";
	 // pen1.Write();
	  //pen2.Write();
	  pen1.print();
	  pen2.print();
	}

}

import java.awt.*;
import java.awt.event.*;
public class FrontDemo extends Frame
{
	FrontDemo()
	{
		this.setVisible(true);
		this.setSize(400,400);
		this.setTitle("FrontDemo");
		addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
	}
	@Override
	public void paint(Graphics g)
	{
		Font fd=new Font("Consol",Font.BOLD,40);
	     g.setFont(fd);
		 g.setColor(Color.blue);
	    g.drawString("Welecome",70,70);
		
	}
	public static void main(String[] args)
	{
		FrontDemo fd=new FrontDemo();
	}
}
/*
import java.awt.*;

public class AWTExample1
{
	AWTExample1()
	{
		//Create a frame 
		Frame frame=new Frame();
		//This is use for frame is visiblr 
		frame.setVisible(true);
		//Setting Frame size 
		frame.setSize(300,300);
	}
	public static void main(String []args)
	{
		AWTExample1 AW=new AWTExample1();
	}
}
*/

// Second Method 
/* in this method we customize 
the property of frame 
*/
import java.awt.Frame;
import java.awt.Color;
public class AWTExample1 extends Frame
{
	AWTExample1()
	{
		this.setVisible(true);
		this.setSize(400,400);
		
		// Create a color 
		//Color c=Color.red;
		//RGB color
		Color c=new Color(130,50,50);
		this.setBackground(c);
		this.setTitle("DEMMo Class");
	}
	
	public static void main(String [] args)
	{
		AWTExample1 aw=new AWTExample1();
	}
}

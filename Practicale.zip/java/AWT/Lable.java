import java.awt.*;
import java.awt.event.*;
public class Lable extends Frame
{
    Lable()
	{
		this.setVisible(true);
		this.setSize(400,400);
		this.setTitle("Lable Frame");
		this.setLayout(null);
		//Create Lable
		Label l1=new Label( "User name");
		Label l2=new Label("Password");
	    // this line give what you enter in label or what you text 
		String text = l1.getText();   // <-- using getLabel()
        System.out.println("The label text is: " + text);
		//Set Location of label
		l1.setBounds(50,100,300,40);
		l2.setBounds(50,150,300,40);
		this.add(l1);
		this.add(l2);
		
		addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
			
            }
        });
	}
     @Override
	public void paint(Graphics g)
	{
		Font f=new Font("Consol",Font.BOLD,40);
		g.setFont(f);
		g.drawString("Welcome",70,70);
	}
       public static void main(String [] args)
	   {
		   Lable fd=new Lable();
	   }

}



import java.awt.*;
import java.awt.event.*;
public class TextFile extends Frame
{
	TextFile()
	{
		this.setTitle("TExtFile");
		this.setSize(400,400);
		this.setLayout(null);
		//Create Label
		Label l1=new Label("User ID");
		TextField t1=new TextField();
		// Set bounds (x, y, width, height)
	    l1.setBounds(50,100,100,30);
		t1.setBounds(150,100,150,30);
        //t1.setText("Enter user name");
		//Create for Password
		this.add(l1);
		this.add(t1);
		//this.add(l2);
		
		Font f=new Font( "Consolas",Font.BOLD,15);
		this.setFont(f);
		addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
			
            }
        });
		this.setVisible(true);
	}
	public static void main(String[] args)
	{
		TextFile T=new TextFile();
	}
}
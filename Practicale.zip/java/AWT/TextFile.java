import java.awt.*;
import java.awt.event.*;
public class TextFile extends Frame
{
	TextFile()
	{
		this.setTitle("TextField");
		this.setSize(400,400);
		Color c=new Color(130,50,50);
		this.setBackground(c);
		this.setLayout(null);
		//Create user name 
		Label l1=new Label( "UserName");
		Label l2=new Label("Password");
		//Create Text
		TextField t1=new TextField();
		TextField t2=new TextField();
		t1.setText("Enter UserName");
		t2.setText("");
		//set this method use for hide the function 
		t2.setEchoChar('*');
		//Set loccation
        l1.setBounds(50,100,150,40);
		t1.setBounds(200,100,150,40);
		l2.setBounds(50,150,150,40);
		t2.setBounds(200,150,150,40);
		this.add(l1);
		this.add(t1);
		this.add(l2);
		this.add(t2);
		Font f=new Font("Consolas",Font.BOLD,15);
		this.setFont(f);
		addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
			
            }
        });
		this.setVisible(true);
		
	}
	
	public static void main(String[] args)
	{
		TextFile f=new TextFile();
	}
}
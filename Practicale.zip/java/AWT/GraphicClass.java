import java.awt.*;
import java.awt.event.*;
public class GraphicClass extends Frame
{
	GraphicClass()
	{
		this.setVisible(true);
		this.setSize(400,400);
		this.setTitle("Chutiya");
		addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
	}
	//@override
	 @Override
	public void paint(Graphics g)
	{
		
		g.drawString("Welcome Raju",50,50);
		//Craete a Reactangle(x,y,Witch,Height) 
		g.drawRect(50,50,40,10);
		//Fill a Reactangle(x,y,Witch,Height) 
        g.fillRect(50,50,40,10);
		//Draw ovel(x,y,Witch,Height) 
		g.drawOval(80,80,40,10);
		g.fillOval(200, 150, 100, 50);
		//g.FillOvel(80,80,40,10);
	}
	public static void main(String[] args)
	{
		GraphicClass  gh=new GraphicClass();


}
}
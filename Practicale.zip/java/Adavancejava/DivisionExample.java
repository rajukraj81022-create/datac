public class DivisionExample {
    public static void main(String[] args) {
        int i = 0;
        int j = 0;
        try{
        Class.forName("hello");
        System.out.println("Class Found");
        }
        catch(ClassNotFoundException e)
        {
            System.out.println(("Class not found "));
        }

        try {
            j = 18 / i;
            if(j==0)
                {
                    throw new ArithmeticException("I don't want to print ");
                }
        } catch (Exception e) {
            j=18/1;

            System.out.println("Cannot divide: " + e);
        }

        System.out.println(j);
        System.out.println("Bye");
    }
}

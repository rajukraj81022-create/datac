import java.util.HashMap;
import java.util.Map;
public class MapJava {
    public static void main(String[]args){
        Map<String,Integer> student=new HashMap<>();
        student.put("Rohan",78);
        student.put("Sohan",78);
        student.put("Anil",78);
        student.put("Sunil",78);
        System.out.println(student.keySet());
        //System.out.println(student);
        for(String key:student.keySet()){
              System.out.println(key +" "+student.get(key));
        }
        
    }
}

class A {
    void show() {
        System.out.println("This class A");
    }

}

public class AnnonmusClass {
    public static void main(String[] args) {
        A obj = new A() {
            void show() {
                System.out.println("Annonmus class");
            }
        };
        obj.show();
    }
}

public class ServerClass
{
    CSQuestion [] question=new CSQuestion[5];
    public ServerClass()
    {
    
    question[0]=new CSQuestion(1,"size of int  is","4","3"," 8 "," 4 "," 4"); 
    
    question[1]=new CSQuestion(2," size of flot is"," 4"," 3"," 8 "," 4 "," 4");
    question[2]=new CSQuestion(1, "Java is?",
                        "Language", "OS", "Browser", "Device",
                        "Language");
    
       question[3]=new CSQuestion(2," size of double is"," 4"," 3"," 8 "," 4"," 8 ");
       question[4]=new CSQuestion(2," size of char is"," 4"," 3"," 8"," 1 "," 1 ");
     
       
    }
    public void DisplayQuestion()
    {
        for(CSQuestion q:question)
            {
                System.out.println(q);
            }
    }
    

}
@FunctionalInterface
  interface  A{

    void Show();
}
public class Lamda {
    public static void main(String[]args)
    {
        A obj= ()->
        {
            System.out.println("in A show");
        };
        obj.Show();
    }
}

interface Computer {
    void Code();
}

class Laptop implements Computer {
    public void Code() {
        System.out.println("Code runs");
    }
}
class Desktop implements Computer{
   public void Code()
   {
    System.out.println("Code run Faster");
   }
}
class Devloper
{
    public void DevApp(Computer comp)
    {
        comp.Code();
    }
}
public class NeedInterface {
    public  static void main(String[]arS)
    {
          Computer obj1=new Laptop();
          Computer obj2=new Desktop();
          Devloper dept=new Devloper();
          dept.DevApp(obj1);
          dept.DevApp(obj2);

    }
}

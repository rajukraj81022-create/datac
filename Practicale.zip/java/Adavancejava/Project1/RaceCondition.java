import java.util.concurrent.SynchronousQueue;

class Counter
{
    int count;
    public synchronized void Increamint()        ///synchronized this is used for one theard work at one time 
    {
        count+=+1;
    }
}
// class A implements  Runnable
// {
//     
//     public void run()
//         {
//             for(int i=0;i<=100;i++)
//                 {
//                     c.Increamint();
//                 }
//         }

// }
// class B implements  Runnable
// {
//     Counter c=new Counter();
//     public void run()
//         {
//             for(int i=0;i<=100;i++)
//                 {
//                     c.Increamint();
//                 }
//         }

// }
public class RaceCondition {
    public void main(String []args)throws InterruptedException
    {
        Counter c=new Counter();
           Runnable obj1=()->{
           
                   
                       for(int i=0;i<=100;i++)
                           {
                               c.Increamint();
                           }
                   
                };
           
           Runnable obj2=()->
           {
            
                    
                        for(int i=0;i<=100;i++)
                            {
                                c.Increamint();
                            }
                    
                };
           Thread T1 = new Thread(obj1);
           Thread T2 = new Thread(obj2);
           T1.start();
           T2.start();
           T1.join();
           T2.join();
           System.out.println("Total number of Count"+"  "+c.count);
    }
}

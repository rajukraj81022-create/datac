class MainClass
{
    public static void main(String[]args)
    {
        ServerClass obj1=new ServerClass();
        obj1.DisplayQuestion();
    }
}
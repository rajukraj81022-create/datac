import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
public class ArrayListjava {
    public static void main(String[]args)
    {
        //Collection<Integer> num=new ArrayList<Integer>();
        List<Integer> num=new ArrayList<Integer>();
        num.add(23);
        num.add(24);
        num.add(2);
        num.add(23);
        System.out.println(num);
            
        for(int n :num)
            {
              System.out.println(n);
            }

    }
    
}

public class CSQuestion
{
    private int id;
    private String Question;
    private String opt1;
    private String opt2;
    private String opt3;
    private String opt4;
    private String ans;
    public CSQuestion()
    {

    }
    public CSQuestion(int id,String Question,String opt1,String opt2,String opt3,String opt4,String ans)
    {
        this.id=id;
        this.Question=Question;
        this.opt1=opt1;
        this.opt2=opt2;
        this.opt3=opt3;
        this.opt4=opt4;
        this.ans=ans;
    }



    public void setId(int id) {
        this.id = id;
    }
    public void setQuestion(String question) {
        Question = question;
    }
    public void setOpt1(String opt1) {
        this.opt1 = opt1;
    }
    public void setOpt2(String opt2) {
        this.opt2 = opt2;
    }
    public void setOpt3(String opt3) {
        this.opt3 = opt3;
    }
    public void setOpt4(String opt4) {
        this.opt4 = opt4;
    }
    public void setAns(String ans) {
        this.ans = ans;
    }
    
    public int getId() {
        return id;
    }
    public String getQuestion() {
        return Question;
    }
    public String getOpt1() {
        return opt1;
    }
    public String getOpt2() {
        return opt2;
    }
    public String getOpt3() {
        return opt3;
    }
    public String getOpt4() {
        return opt4;
    }
    public String getAns() {
        return ans;
    }
    public String toString() {
        return "ID: " + id +
               "\nQuestion: " + Question +
               "\nOption 1: " + opt1 +
               "\nOption 2: " + opt2 +
               "\nOption 3: " + opt3 +
               "\nOption 4: " + opt4 +
               "\nAnswer: " + ans;
    }
    public static void main(String args[])
    {
     
    }
}
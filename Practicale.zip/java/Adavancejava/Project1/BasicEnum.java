enum Status
{
    Running, Failled,Pending,Success; // All are object of enum
}
public class BasicEnum {
    public static void main(String[]args)
    {
            Status S=Status.Running;
        //    System.out.println(S);
        Status []ss=Status.values();
        for(Status s:ss)
            {
                System.out.println(s+"  "+s.ordinal());
            }
            if(S==Status.Failled)
                {
                    System.out.println("Try Again");
                }
            if(S==Status.Pending)
                {
                    System.out.println("Please Wait");
                }
            
            if(S==Status.Running)
                {
                    System.out.println("All Good");
                } 
                else
                    {
                        System.out.println("Done");       
                    }   
    }
}

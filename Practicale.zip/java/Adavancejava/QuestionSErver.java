import java.util.Scanner;
public class QuestionSErver {
    CQuestion[] question=new CQuestion[5] ;
    QuestionSErver(){
    question[0]=new CQuestion(1,"size of int  is","4","3"," 8 "," 4 "," 4"); 
    
    question[1]=new CQuestion(2," size of flot is"," 4"," 3"," 8 "," 4 "," 4");
    question[2]=new CQuestion(1, "Java is?",
                        "Language", "OS", "Browser", "Device",
                        "Language");
    
       question[3]=new CQuestion(2," size of double is"," 4"," 3"," 8 "," 4"," 8 ");
       question[4]=new CQuestion(2," size of char is"," 4"," 3"," 8"," 1 "," 1 ");
    }

              public void DisplayQuestion() {
                for(CQuestion q:question)
                {
                  System.out.println(q);
                }
              }
       String selection[]=new String[5]; 
       int i=0;
        public void PlayQuiz()
        {
            for(CQuestion q:question)
            {
                System.out.print("question no"+q.getID());
                System.out.println(q.getQuestion());
                System.out.println("A"+q.getOpt1());
                System.out.println(q.getOpt2());
                System.out.println(q.getOpt3());
                System.out.println(q.getOpt4());
                Scanner sc=new Scanner(System.in);
                System.out.println("Entere the your choice");   
                selection[i++]=sc.next();
            }
            System.out.println("User choose Opation");
            for(String s:selection)
            {
               System.out.println(s);
            }
        }
        public void Score()
        {
            int score=0;
            for(int i=0;i<5;i++)
            {
                if(selection[i].equals(question[i].getAns()))
                {
                    score++;
                }
            }
            System.out.println(score);
        }
    public static void main(String []args)
    {
        
                
    
     }
    
}

public class CQuestion {
    private int ID;
    private String Question;
    private String Opt1;
    private String Opt2;
    private String Opt3;
    private String Opt4;
    private String Ans;
    public CQuestion()
    {

    }
    public CQuestion(int ID,String Question,String opt1,String opt2,String opt3,String opt4,String Ans)
    {
        this.ID=ID;
        this.Question=Question;
        this.Opt1=opt1;
        this.Opt2=opt2;
        this.Opt3=opt3;
        this.Opt4=opt4;
        this.Ans=Ans;
    } @Override
    public String toString() {
        return "ID: " + ID +
               "\nQuestion: " + Question +
               "\nOption 1: " + Opt1 +
               "\nOption 2: " + Opt2 +
               "\nOption 3: " + Opt3 +
               "\nOption 4: " + Opt4 +
               "\nAnswer: " + Ans;
    }
    
    public int getID() {
        return ID;
    }
    public void setID(int iD) {
        ID = iD;
    }
    public String getQuestion() {
        return Question;
    }
    public void setQuestion(String question) {
        Question = question;
    }
    public String getOpt1() {
        return Opt1;
    }
    public void setOpt1(String opt1) {
        Opt1 = opt1;
    }
    public String getOpt2() {
        return Opt2;
    }
    public void setOpt2(String opt2) {
        Opt2 = opt2;
    }
    public String getOpt3() {
        return Opt3;
    }
    public void setOpt3(String opt3) {
        Opt3 = opt3;
    }
    public String getOpt4() {
        return Opt4;
    }
    public void setOpt4(String opt4) {
        Opt4 = opt4;
    }
    public String getAns() {
        return Ans;
    }
    public void setAns(String ans) {
        Ans = ans;
    }
    public static void main(String[]args)
    {

    }


    
}

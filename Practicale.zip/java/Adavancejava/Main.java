public class Main
{
    
   public  static void main(String []args) {
       
    QuestionSErver object=new QuestionSErver();

    object.DisplayQuestion();
   // object.PlayQuiz();
    //object.Score();
   }
}
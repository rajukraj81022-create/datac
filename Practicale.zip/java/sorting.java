//import java.util.*;
//public class sorting{
   /* public static void BubbleSort(int arr[],int size)
	{
		int temp=0;
		for(int i=0;i<size-1;i++)
		{
		  for(int j=i;j<size-1;j++)
		  {
			  if(arr[j]>arr[j+1])
			  {
				  temp=arr[j];
				  arr[j]=arr[j+1];
				  arr[j+1]=temp;
				  
			  }
		  }
		}
		
	}
	*/
// selection sorting

  /*
     public static void SelectionSort(int arr[],int size)
	 {
		 for(int i=0;i<size-1;i++)
		 {
			 int minIndex=i;
			 for(int j=i+1;j<size-1;j++)
			 {
				 if(arr[j]<arr[minIndex])
				 {
					 minIndex=j;
				 }
			 }
			 int minValue=arr[minIndex];
			 arr[minIndex]=arr[i];
			 arr[i]=minValue;
		 }
	 }
	*/
	
	// Insertion sort
	
	/*
	
     public static void InsertionSort(int arr[] ,int size)
    {
	     for(int i=1;i<size;i++)
		 {  
	        int current =arr[i];
			int j=i-1;
			 while(j>=0 && current<arr[j])
			 {
				 arr[j+1]=arr[j];
				 j--;
			 }
			 arr[j+1]=current;
		 }
	
     }
	
    public static void main(String[] args){
     
	 Scanner sc = new Scanner(System.in);
	 System.out.print("Enter the size of array");
	 int size=sc.nextInt();
     int arr[]=new int[size];
	 System.out.println("Enter the elment ");
     for(int i=0;i<size;i++)
	 {
		 arr[i]=sc.nextInt();
	 }
	  System.out.println("After the sorting of array");
     InsertionSort(arr,size);
    for(int i=0;i<size;i++)
	{
	System.out.println(arr[i]);
	
	}
   
  
}
}



*/


///MERGE SORT
import java.util.*;
public class sorting{
	public static void conquer(int arr[],int Si,int mid,int Li)
	{
		int newArr[]=new int[ Li-Si+1];
		int ind1=Si;
		int ind2=mid+1;
		int x=0;
		while(ind1<=mid && ind2<=Li)
		if(arr[ind2]<arr[ind1])
		{
			newArr[x]=arr[ind2];
			ind2++;
			x++;
		}
		else
		{
			newArr[x]=arr[ind1];
			ind1++;
			x++;
		}
		while(ind2<=Li)
		{
			newArr[x]=arr[ind2];
			x++;
			ind2++;
		}
		while(ind1<=mid)
		{
			newArr[x]=arr[ind1];
			x++;
			ind1++;
		}
		for(int i=0,j=Si;i<newArr.length;i++,j++)
		{
			arr[j]=newArr[i];
		}
		
	}
	public static void MergeSort(int arr[],int Si,int Li)
	{
		if(Si>=Li)
		{
			return ;
		}
		int mid=Si+(Li-Si)/2;
		MergeSort(arr,Si,mid);
		MergeSort(arr,mid+1,Li);
		conquer(arr, Si,mid,Li);
	}
	public static void main( String [] urgs){
	  Scanner sc=new Scanner(System.in);
	  System.out.print("enter the size of array:");
	  int size=sc.nextInt();
	  int arr[]=new int[size];
	  System.out.println("enter the element of array");
	  int i;
	  for( i=0;i<size;i++)
	  {
		  arr[i]=sc.nextInt();
	  }
	  System.out.println(" the element of array");
	  for(i=0;i<size;i++)
      {
	  System.out.println(arr[i]);
	
	}
	System.out.println("After the Merge Sort ");
	MergeSort( arr, 0,size-1);
	for(i=0;i<size;i++)
      {
	  System.out.println(arr[i]);
	
	}
}	

}
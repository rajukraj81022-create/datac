
/*
interface Bicycle{
    void Break(int decriment);
	void SpeedUp(int incriment);
}
class AvonCycle implements Bicycle
{
	public void Blow()
	{
		System.out.println("Pee pee pee");
	}
	public void Break(int decriment)
	{
		System.out.println("Applying Break");
	}
	public void SpeedUp(int incriment)
	{
		System.out.println("Increase Speed");
	}
}
public class Interface
{
	public static void main(String[] args)
	{
		AvonCycle obj=new AvonCycle();
		obj.Break(1);
	}
}
*/


// Default interface 

/*
interface Mycamera
{
	void taksnape();
	void takepicture();
}
interface Wifi
{
	String[] getNetwork();
	void connectNetwork(String network);
}
class MycellPhone
{
	public void calling()
	{
		System.out.println("Calling....");
	}
	void PickCall()
	{
		System.out.println("Connecting....");
	}
}
class SmartPhone extends MycellPhone implements Mycamera,Wifi
{
	public void takepicture()
	{
		System.out.println("Tanking Picture");
	}
	public void taksnape()
	{
		System.out.println("Tanking Snap");
	}
	public String[] getNetwork()
	{
		System.out.println("Getting Network List");
		String[]NetworkList={"Rohan","Redmi5G","ScootyTcs"};
		return NetworkList;
	}
	public void connectNetwork(String Network)
	{
		System.out.println("Connecting..."+Network);
	}
}
public class Interface
{
	public static void main(String[] args)
	{
		SmartPhone Redmi=new SmartPhone();
		String[]ar=Redmi.getNetwork();
      for(String item:ar)
	  {
	     System.out.println(item);
      }	
     Redmi.connectNetwork("Redmi5G");	  
	}
}

*/

// Inhertance in Interface

interface SampleinterFace
{
	void Math1();
	void Math2();
}
interface childInterface extends SampleinterFace
{
	void Math3();
	void Math4();
}
 class Myclass implements childInterface{
   
	 public void Math1()
	   {
		   System.out.println("This is math1");
	   }
	public void Math2()
	{
		System.out.println("This is Math2");
	}
	public  void Math3()
	   {
		   System.out.println("This is Math3");
	   }
	public void Math4()
	{
		System.out.println("This is Math4");
	}
   
}

public class Interface
{
   public static void main(String [] args)
   {
	   Myclass obj=new Myclass();
	   obj.Math1();
   }

}
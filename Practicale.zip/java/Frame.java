import java.awt.*;
public class Frame exteds window implement MenuContair
{
   public static void main(String [] args)
   {
      public void Frame();
   }
}
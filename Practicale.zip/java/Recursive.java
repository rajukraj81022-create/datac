/*
public class Recursive{
 
     public static int sum(int n)
	 {
		 
		 if(n==0)
		 {
			 return 0;
		 }
		 else
		 {
			 return n+=sum(n-1);
		 }
		 
	 }
     public static void main(String[] args){
	     
		 System.out.print(sum(5));
	    
	 
	 
	 }
  
  }
*/

// Calaculate the power 
/*
import java.util.*;
public class Recursive{
	 public static int power(int a,int b)
	 {
		 if(b==0)
		 {
			 return 1;
		 }
		 else
		 {
		     return (a*power(a,(b-1)));
		 }
	 }
    public static void main(String[] args){
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter the number: ");
     int a=sc.nextInt();
      int b=sc.nextInt();	
      System.out.print(power(a,b));	  
	}

}

*/

//Second Method
/*
import java.util.*;
public class Recursive{
	public static int power(int x,int n)
	{
		if(n==0)
		{
			return 1;
		}
		if(n%2==0){
		  return (power(x,n/2)*power(x,n/2));
		}
		else{
	      return (power(x,n/2)*power(x,n/2)*x);
      	}
		
	}
	
  public static void main(String[] args)
  {
	  
	  System.out.print(power(2,3));
  }

}
*/



// Tower of Honoi

/*

public class Recursive{
	public static void towerofHonoi(int n,String Src,String dest,String help)
	{
		if(n==1)
		{
			System.out.println("Transfer Disk  "+n+"  from  "+Src+"  To  "+dest);
			return ;
		}
		towerofHonoi(n-1,Src,help,dest);
		 System.out.println("Transfer Disk  "+n+" from "+Src+" To "+dest);
		towerofHonoi(n-1,help,dest,Src);
	}
    public static void main(String[] args)
	{
	  int n=3;
	  towerofHonoi(n,"S","D","H");
	 
	}

}

*/
//// Reverse the String
/*
public class Recursive{
	
	public static void Reverse(String s ,int i)
	{
		if(i==0)
		{
			System.out.print(s.charAt(i));
			return ;
		}
		System.out.print(s.charAt(i));
		Reverse(s,i-1);
	}
   public static void main(String[] args)
   {
	   String name="abcd";
	   Reverse(name,name.length()-1);
   
   }

}

*/



// Find the occurance of string 
/*
public class Recursive{
	
	static int first=-1;
	static int last=-1;
	public static void occurance(String str,int ind,char a)
	{
		if(ind==str.length())
		{
			System.out.print("First index is : "+first+"  Last element is: "+last);
			return;
		}
		int current =str.charAt(ind);
		if(current==a)
		{
			if(first==-1)
		    {
				first=ind;
			}
			else{
			  last=ind;
			}
		}
		occurance(str,ind+1,a);
	}
   public static void main(String[]args){
       
    String str="abaacdaefaah";
     occurance(str,0,'a');	
   
   }

 }
 
 
 */
 
 
 
 //Check the array is sorted or not 

/*
public class Recursive
{
	public static void boolen(int arr[],int size,int ind)
	{
		if(ind==size-1)
		{
			System.out.println("True");
			return ;
		}
		if(arr[ind]>=arr[ind+1])
		{
			System.out.println("False");
			return;
		}
		else{
		   boolen(arr,size,ind+1);
		}
	}
	public static void main(String[] args){
	    int arr[]= {1,2,3,4,5};
		int size=arr.length;
		boolen(arr,size,0);
	
	
	}

}
 */
 
 
 //move all x to end of string axbcxxd
 
 /*
 public class Recursive{
	 static StringBuilder sc=new StringBuilder();
	 public static void Move(String str,char x,int ind)
	 {
		 if(ind==str.length())
		 {
			 System.out.print(sc);
			 return ;
		 }
		 char current=str.charAt(ind);
		 if(current==x)
		 {
            sc.append(current);
		 }
		 else{
		    System.out.print(current);
		 }
		 Move(str,x,ind+1);
	 }
     public static void main(String[] args)
	 {
		 String str="axbcxxd";
		 char z='x';
		 Move(str,z,0);
	 }
 
 }
*/

//Remove duplicate from String  abbccda

/*
public class Recursive{
     static String newstr="";
	public static void Remove(String str,int ind)
	{
	
		if(ind==str.length())
		{
			System.out.print(newstr);
			return ;
		}
		char current =str.charAt(ind);
		
		boolean found = false;
        int i = 0;
        while (i < newstr.length()) {
            if (current == newstr.charAt(i)) {
                found = true;
                break;
            }
            i++;
        }

        if (!found) {
            newstr += current;
        }
		  Remove(str,ind+1);
     }
	
    public static void main(String[] args){
	   String str="abbccda";
	  
	   Remove(str,0);
	}
}

*/





/*
public class Recursive{
	public static void permutaion(Strnig str,String perm)
	{
		for(int i=0;i<=str.length();i++)
		{
			
		}
	}
  public static void main(String[] args)
  {
	  
  }

*/
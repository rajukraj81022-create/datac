//import java.util.*;
//public class Main {
  //  public static void main(String[] args) {
	//	for(int i=0;i<=50;i++)
	//	{
      //  System.out.println("HELLO World");
	//	}
  //  }
//}

/*
public class Main{
public static void main(String[] args){
 Scanner sc=new Scanner(System.in);
 int n=sc.nextInt();
 int sum=0;
 for(int i=1;i<=n;i++)
 {
     sum+=i;
 }
 System.out.println(sum);
 }
}

*/

// print the table number input by user 

import  java.util.*;

public class Main{
   public static void main(String[] args){
     Scanner sc=new Scanner(System.in);
	 System.out.println("ENTER THE NUMBER= ");
	 int n=sc.nextInt();
	for(int i=1;i<=10;i++)
	{
		 System.out.println(n*i);
	}
	 
   }
}



import java.io.*;
import java.net.*;

public class ClientDemo {
    public static void main(String[] args) {
        try {
            // Connect to server
            Socket s = new Socket("localhost", 8000);
            System.out.println("Connection established with server.");

            // Input stream to read data from server
            DataInputStream dis = new DataInputStream(s.getInputStream());

            // Read initial message from server
            String msg = dis.readUTF();
            System.out.println(msg);

            // Prepare to receive file
            FileOutputStream fos = new FileOutputStream("AEvent.class");
            byte[] buffer = new byte[4096];
            int bytesRead;

            System.out.println("Receiving file from server...");

            // Read file data until end of stream
            while ((bytesRead = dis.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }

            fos.close();
            System.out.println("File received successfully!");

            // Optional: load and run the received class
            try {
                Class<?> cls = Class.forName("AEvent");
                System.out.println("Class loaded successfully: " + cls.getName());
                cls.getMethod("main", String[].class).invoke(null, (Object) new String[0]);
            } catch (Exception ex) {
                System.out.println("Could not load or run AEvent: " + ex);
            }

            dis.close();
            s.close();

        } catch (IOException e) {
            System.out.println("Error: " + e);
        }
    }
}
import java.awt.*;
import java.awt.event.*;

public class AEvent extends Frame implements ActionListener, WindowListener {

    TextField tf;
    Button submitBtn;

    AEvent() {
        // Create input text field
        tf = new TextField();
        tf.setBounds(60, 80, 170, 25);

        // Create Submit button
        submitBtn = new Button("Submit");
        submitBtn.setBounds(100, 130, 90, 30);
        submitBtn.addActionListener(this);

        // Add components to frame
        add(tf);
        add(submitBtn);

        // Frame properties
        setSize(300, 250);
        setTitle("Message Sender");
        setLayout(null);
        setVisible(true);
        addWindowListener(this);
    }

    // Handle button click
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitBtn) {
            String input = tf.getText();

            if (input.isEmpty()) {
                // Show warning dialog if no input
                showMessageDialog("Please enter a message before submitting!");
            } else {
                // Show success dialog
                showMessageDialog("Message sent successfully!");
                tf.setText(""); // clear text after submission
            }
        }
    }

    // Custom method to show dialog box
    private void showMessageDialog(String message) {
        Dialog d = new Dialog(this, "Alert", true);
        d.setLayout(new FlowLayout());
        Label l = new Label(message);
        Button ok = new Button("OK");

        ok.addActionListener(e -> d.setVisible(false));

        d.add(l);
        d.add(ok);
        d.setSize(250, 120);
        d.setLocationRelativeTo(this);
        d.setVisible(true);
    }

    // Window listener methods
    public void windowClosing(WindowEvent e) {
        System.exit(0);
    }

    public void windowOpened(WindowEvent e) {
    }

    public void windowClosed(WindowEvent e) {
    }

    public void windowIconified(WindowEvent e) {
    }

    public void windowDeiconified(WindowEvent e) {
    }

    public void windowActivated(WindowEvent e) {
    }

    public void windowDeactivated(WindowEvent e) {
    }

    // Main method
    public static void main(String[] args) {
       AEvent f= new AEvent();
    }
}
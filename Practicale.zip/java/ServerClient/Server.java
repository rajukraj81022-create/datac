import java.io.*;
import java.net.*;
public class  Server
{
	public static void main(String[]args)
	{
		try
		{
		ServerSocket ss=new ServerSocket(8000);
		System.out.println("Waiting for connection");
		while(true)
		{
		  Socket s=ss.accept();//client
		  System.out.println("Connection is Estbalish");
		//write or sent outputStream
		  PrintStream ps=new PrintStream(s.getOutputStream());
		  // File to send
		   DataOutputStream dos = new DataOutputStream(s.getOutputStream());
            File file = new File("AEvent.class");
            if (!file.exists()) {
                System.out.println("File not found!");
                ss.close();
                s.close();
                return;
            }
            // Send file data
            FileInputStream fis = new FileInputStream(file);
            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = fis.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
            }

            fis.close();
            dos.flush();
            System.out.println("File sent successfully!");
		  ps.print("Welcome"); // print messages
		  fis.close();
          dos.flush();
		  s.close();
		  }
		}
		catch(IOException e)
		{
			System.out.println("Error"+e);
		}
	}
}
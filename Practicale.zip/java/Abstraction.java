
/*

class circle{
	public int radis;
     circle(int r)
	 {
	     this.radis=r; 
	 }
     public double area()
	 {
		 return Math.PI *this.radis*this.radis;
	 }
}
class cylinder extends circle{
     public int height;
	 public cylinder(int r,int h)
	 {
		 super(r);
		 this.height=h;
		 
	 }
	 public double volum()
	 {
		 return Math.PI*this.radis*this.height;
	 }

}
public class Abstraction
{
	public static void main(String [] args)
	{
		cylinder obj=new cylinder(12,13);
		System.out.println(obj.area());
		System.out.println(obj.volum());
	}
}	
*/


// ABstract class 
abstract class Parent{
      public Parent()
	  {
		  System.out.println("This is Parent class ");
	  }
	  public void SayHello()
	  {
		  System.out.println("Hello");
	  }
	  abstract public void Greet();
}
class Child extends Parent{
     @Override
      public void Greet()
	  {
		  System.out.println("Good Mornig");
	  }
 }
public class Abstraction{
     public static void main(String[] args)
	 {
		 Child obj=new Child();
	 }
}	







/*
import java.util.*;
public class Pattern{
   public static void main(String[] args){
       Scanner sc=new Scanner(System.in);
	  System.out.println("enter the number of row = ");
	  int n=sc.nextInt();
	  System.out.println("enter the number of column  ");
	  int m=sc.nextInt();
	  for(int i=0;i<n;i++)
	  {
		  for(int j=0;j<m;j++)
		  {
			 System.out.print("*");
		  }
		  System.out.print("\n");
	  }
   
   }
}

*/
/*
import java.util.*;
 public class Pattern{
  public static void main(String[] args){
  Scanner sc=new Scanner(System.in);
  System.out.println("enter the number of row = ");
  int n=sc.nextInt();
  System.out.println("enter the number of column = ");
  int m=sc.nextInt();
  for(int i=0;i<n;i++)
  {
	  for(int j=0;j<m;j++)
	  {
		  if(i==0 ||i==1||i==2||i==n-3||i==n-2||i==n-1)
		  {
			  System.out.print("*");
		  }
		  else if(j==0||j==1||j==2||j==m-3||j==m-2||j==m-1)
		  {
			  System.out.print("*");
		  }
		else{
			System.out.print(" ");
		}
	  }
	  System.out.print("\n");
  }
  } 
}
*/

/*
import java.util.*;
 public class Pattern{
  public static void main(String[] args){
  Scanner sc=new Scanner(System.in);
  System.out.println("enter the number of row = ");
  int n=sc.nextInt();
  System.out.println("enter the number of column = ");
  int m=sc.nextInt();
  for(int i=0;i<n;i++)
  {
	  for(int j=0;j<m;j++)
	  {
		  if(i==0 ||i==1||i==n-2||i==n-1)
		  {
			  System.out.print("*");
		  }
		  else if(j==0||j==1||(i==3&&j==3)||( i==4&&j==3)||( i==5&&j==3)||(i==3&&j==m-4)||( i==4&&j==m-4)||( i==5&&j==m-4)||j==m-2||j==m-1)
		  {
			  System.out.print("*");
		  }
		  else if((i==3&&j==4)||(i==5&j==4))
		  {
			  System.out.print("*");
		  }
		else{
			System.out.print(" ");
		}
	  }
	  System.out.print("\n");
  }
  } 
}
*/

// function in java 

import javax.swing.*;
import java.awt.*;
/*
public class Label {
    public static void main(String[] args) {
        // Create the main frame
        JFrame frame = new JFrame("User Profile");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 500);
        frame.setLayout(new BorderLayout());

        // Load and scale the image
        ImageIcon icon = new ImageIcon("Birdimage.png");
        Image scaledImage = icon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH);
        icon = new ImageIcon(scaledImage);

        // Create label for image
        JLabel imageLabel = new JLabel(icon);
        imageLabel.setHorizontalAlignment(JLabel.CENTER);
        imageLabel.setVerticalAlignment(JLabel.CENTER);

        // Ask user for name
		//This line opens a small dialog box (popup window) that asks the user for input.
        String username = JOptionPane.showInputDialog("Enter your username:");
        if (username == null || username.trim().isEmpty()) {
            username = "Unknown User";
        }

        // Create username label (bottom)
        JLabel nameLabel = new JLabel(username, JLabel.CENTER);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 18));
        nameLabel.setForeground(Color.DARK_GRAY);
        nameLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 20, 0));

        // Add components to frame
        frame.add(imageLabel, BorderLayout.CENTER);
        frame.add(nameLabel, BorderLayout.SOUTH);

        // Show window
        frame.setVisible(true);
    }
}
*/

import javax.swing.border.*;   // use for Border mark

public class Label
{
	public static void main(String[] args)
	{
		JFrame frame=new JFrame("User Profile");
		frame.setSize(450,450);
		frame.setLayout( null);
		frame.setLayout(new BorderLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//create image
		ImageIcon icon = new ImageIcon("Birdimage.png");
        Image scaledImage = icon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        icon = new ImageIcon(scaledImage);

		JLabel l1=new JLabel(icon);  //crete label
		//l1.setIcon(icon);
		//Border border= BorderFactory.createLineBorder(Color.green,3);
		Border border = BorderFactory.createLineBorder(Color.GREEN, 3);
		l1.setText("UserName");
		l1.setBounds(50,50,300,30);
		 l1.setHorizontalTextPosition(JLabel.CENTER);   // text right of image
        l1.setVerticalTextPosition(JLabel.TOP);    // vertically centered
        l1.setFont(new Font("Arial", Font.BOLD, 16)); // Change the font 
		l1.setForeground(Color.green);
		l1.setFont(new Font("MV BOLI",Font.BOLD,20));
		l1.setIconTextGap(20);   //gap bw image and text
		l1.setVerticalAlignment(JLabel.CENTER);  //set vertical icon+Text at center
		l1.setHorizontalAlignment(JLabel.CENTER);
		
		l1.setBackground(Color.red);
		l1.setOpaque(true);//wothout use this background color is transparent
		//set Border 
		l1.setBorder(border);
		
		frame.add(l1);
		//l1.setPack();
		frame.setVisible(true);
		
	}		
}
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import java.awt.Color;
public class SwingDemo
{
	public static void main(String[] args)
	{
		JFrame frame=new JFrame();//Create folder
		frame.setTitle("Jframe Demo");//set Title
		frame.setSize(400,400);//set frame size
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//close window
		frame.setResizable(true);// use for resize
		ImageIcon image=new ImageIcon("Birdimage.png");//Craete an Image 
		frame.setIconImage(image.getImage());//Change Icon of the frame 
		Color c=new Color(150,50,70);
		frame.getContentPane().setBackground(c);
		frame.setVisible(true);
	
	}
}
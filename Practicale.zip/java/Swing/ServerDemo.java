import java.io.*;
import java.net.*;
public class ClientDemo
{
	public static void main(String[] args)
	{
		try
		{
			Socket s=new Socket("30.47.67",245);
			DataInputStream inp=new DataInputStream();
			        (s.getInputStream());
		 boolean more_data=true;
         System.out.println("Establish connection");
          while(more_data)
		  {
			  String line=inp.readLine();
			  if(line==null)
			  {
				  more_data=false;
			  }
			  System.out.println(line);
		  }			  
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
}
import javax.swing.*;
import java.awt.*;
public class JPannel
{
	public static void main(String [] args)
	{
		JPanel redpanel=new JPanel();
		redpanel.setBounds(0,0,100,100);
		
        redpanel.setBackground(Color.red);
		JPanel bluepanel=new JPanel();
		bluepanel.setBounds(25,0,100,100);
		bluepanel.setBackground(Color.blue);
		JLabel lavel=new JLabel();
		lavel.setText("Hii");
		JFrame frame=new JFrame();
		frame.setTitle("Level Windows");
		frame.setSize(400,400);
		frame.setLayout( null);
		frame.setLayout(new BorderLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(redpanel);
	    frame.add(bluepanel);
		redpanel.add(lavel);
		frame.setVisible(true);

		
	}
}
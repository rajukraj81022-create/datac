// POLYMORPHISM IN INTERFACE 
interface Mycamera
{
	void taksnape();
	void takepicture();
}
interface Wifi
{
	String[] getNetwork();
	void connectNetwork(String network);
}
class MycellPhone
{
	public void calling()
	{
		System.out.println("Calling....");
	}
	void PickCall()
	{
		System.out.println("Connecting....");
	}
}
class SmartPhone extends MycellPhone implements Mycamera,Wifi
{
	public void takepicture()
	{
		System.out.println("Tanking Picture");
	}
	public void taksnape()
	{
		System.out.println("Tanking Snap");
	}
	public String[] getNetwork()
	{
		System.out.println("Getting Network List");
		String[]NetworkList={"Rohan","Redmi5G","ScootyTcs"};
		return NetworkList;
	}
	public void connectNetwork(String Network)
	{
		System.out.println("Connecting..."+Network);
	}
}
public class PolymorfismInInterface
{
	public static void main(String[] args)
	{
		Mycamera cam1=new SmartPhone();
		cam1.takepicture();
        //This is not allow 
		//cam1.PickCall();
		//cam1.getNetwork();		
	}
}

#include<iostream>
using namespace std;
class CReact
{
    int width;
    int height;
    public:
    CReact(int ,int);
    void area();
};
CReact::CReact(int a,int b)
{
    width=a;
    height=b;
}
void CReact::area()
{
    cout<<"Area Of :"<<width*height;
}
int main()
{
    CReact obj(3,4);
    obj.area();
    return 0;
}
#include<iostream>
using namespace std;
class CReact
{
    int *width;
    int *height;
    public:
    CReact(int a,int b);
    void Area();
    ~CReact()
    {
        delete width;
        delete height;
        cout<<"Destrucor is clled\n";
    }
};
CReact::CReact(int a,int b)
{
    width=new int ;
    height=new int ;
    *width=a;
    *height=b;
}
void CReact::Area()
{
   cout<<*width* *height;
}
int main()
{
    CReact obj(3,4);
    obj.Area();
}

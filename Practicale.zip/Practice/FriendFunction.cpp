#include<iostream>
using namespace std;
class CReact
{
    int width;
    int height;
    public:
    CReact()
    {

    }
    CReact(int a,int b);
    friend CReact duplicate(CReact obj);
    void Area()
    {
        cout<<"Area is :"<<width*height;
    }
};
CReact::CReact(int a,int b)
{
    width=a;
    height=b;
}
CReact duplicate(CReact obj)
{
    CReact parm;
    parm.width=obj.width*2;
    parm.height=obj.height*2;
    return parm;

}
int main()
{
    CReact Rect1(3,4);
    cout<<"Area of Reactangle\n";
    Rect1.Area();
    CReact Rect2=duplicate(Rect1);
    cout<<"Area of ReactangleB \n";
    Rect2.Area();
    return 0;
}
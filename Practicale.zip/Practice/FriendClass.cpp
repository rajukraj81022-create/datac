#include<iostream>
using namespace std;
class Square;
class CReact
{
    int width;
    int height;
    public:
    CReact(int a,int b);
    void convert(Square obj);
    void area()
    {
        cout<<"Area is :"<<width*height<<endl;
    }
};
class Square
{
    int side;
    public:
    Square(int a)
    {
        side=a;
    }
    friend class CReact;
};
void CReact::convert(Square obj)
{
    width=obj.side;
    height=obj.side;
}
CReact::CReact(int a,int b)
{
    width=a;
    height=b;
}
int main()
{
    Square sqr(4);
    CReact obj(3,4);
    cout<<"Area of Reactangle\n";
    obj.area();
    obj.convert(sqr);
    cout<<"Area of Reactangle\n";
    obj.area();
    return 0;
}

public class JavaBasic
{
    int Roll;
    String Name;
    int age;
    void set(int a,String b,int c)
    {
         Roll=a;
         Name=b;
         age=c;
    }
    void get()
    {
        System.out.println(Roll);
        System.out.println(Name);
        System.out.println(age);

    }
    public static void main(String[]args)
    { 
         JavaBasic st1=new JavaBasic();
         st1.set(101,"Rohan",22); 
         st1.get();
         
    }
}
#include<iostream>
using namespace std;
class Vector
{
    public:
    int x;
    int y;
    Vector()
    {

    }
    Vector(int a,int b)
    {
        x=a;
        y=b;
    }
    Vector operator>(Vector obj);
};
Vector Vector::operator>(Vector obj)
{
    Vector parm;
    parm.x=x>obj.x;
    parm.y=y>obj.y;
    return parm;
}
int main()
{
    Vector obj2(2,3);
    Vector obj1(4,4);
    Vector c(obj1>obj2);
    cout<<c.x<<" "<<c.y;
    return 0;
}
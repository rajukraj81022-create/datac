#include<iostream>
using namespace std;
class Myclass
{
    public:
    int val;
    int copynumber;
    //Normal Constructor 
    Myclass(int i)
    {
        val=i;
        copynumber=0;
    }
    //Copy Constructor 
    Myclass(const Myclass &obj)
    {
        val=obj.val;
        copynumber=obj.copynumber+1;
    }
    ~Myclass();
    int get()
    {
        cout<<val<<endl;
    }
};
void Display(Myclass obj)
{
obj.get();
}
Myclass::~Myclass()
{
    if(copynumber==0)
    {
        cout<<"Destroying origanal\n";
    }
    else{
        cout<<"Destroying duplicate \n";
        cout<<copynumber<<endl;
    }
}
int main()
{
    Myclass obj(10);
    Display(obj);
}
#include<iostream>
using namespace std;
class Polygon
{
    public:
    int width;
    int height;
    void set(int a,int b)
    {
        width=a;
        height=b;
    }
};
class CReact: public Polygon
{
    public:
    void area()
    {
        cout<<"area of Reactangle"<<width*height<<endl;
    }
};
class Triangle:public Polygon
{
    public:
    void area()
    {
       cout<<"area of Triangle:"<<(width*height)/2;
    }
};
int main()
{
    CReact React;
    Triangle Tria;
    React.set(3,4);
    Tria.set(3,4);
    React.area();
    Tria.area();
    return 0;
}

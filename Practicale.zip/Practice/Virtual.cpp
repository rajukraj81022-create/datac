#include<iostream>
using namespace std;
class Polygon
{
    public:
    int width;
    int height;
    void set(int a,int b)
    {
        width=a;
        height=b;
    }
  virtual  int area()
    {
      return 0;
    }
};
class Creact:public Polygon
{
    public:
    int area()
    {
        return (width*height);
    }
};
class Triangle:public Polygon
{
    public:
    int area()
    {
        return (width*height)/2;
    }
};
int main()
{
    Triangle tria;
    Creact React;
    Polygon *Poly1= &tria;
    Polygon *Poly2= &React;
    Polygon *Poly3= new Polygon();
    Poly1->set(4,3);
    Poly2->set(4,3);
   cout<< Poly1->area()<<endl;
    cout<<Poly2->area()<<endl;
    cout<<Poly3->area()<<endl;
    return 0;

}
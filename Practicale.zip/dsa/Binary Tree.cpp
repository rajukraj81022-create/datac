#include<iostream>
using namespace std;
class Binary
{
	public:
	int data;
	Binary *left;
	Binary *Right;
	Binary(int data)
	{
		this->data=data;
		this->left=NULL;
		this->Right=NULL;
	}
};
Binary *Insertion(Binary *root,int data)
{
	if(root==NULL)
	{
		root=new Binary(data);
		return root;
	}
	if(data>root->data)
	{
		root->Right=Insertion(root->Right,data);
	}
	else{
	   root->left=Insertion(root->left,data);
	}

return root;
}
void inorder(Binary *root)
{
	if(root==NULL)
	{
		return;
	}
	else
	{
		inorder(root->left);
		cout<<root->data<<endl;
		inorder(root->Right);
	}
}
void input(Binary *&node)
{
	int data=0;
	while(true)
	{
		cout<<"enter the data";
		cin>>data;
		if(data==-1)
		{
			break;
		}
		node=Insertion(node,data);
	}
}
int main()
{
	Binary *root=NULL;
	input(root);
	inorder(root);
	
}
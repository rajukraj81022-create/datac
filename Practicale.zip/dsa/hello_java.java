public class hello_java {
    
    // Your program begins with a call to main()
    public static void main(String[] args)
    {
        // Prints "Hello, World" to the terminal window.
        System.out.println("Hello, World");
    }
}
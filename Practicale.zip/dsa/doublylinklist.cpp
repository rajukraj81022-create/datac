#include<iostream>
using namespace std;
class Node{
	public:
	int data;
	Node *next;
	Node *prev;
};
void traverse( Node *head)
{
	Node *temp=new Node();
	temp=head;
	while(temp!=NULL)
	{
		cout<<temp->data<<"\n";
		temp=temp->next;
	}
}
Node *reverse(Node *head)
{
	Node *temp=new Node();
	temp=head;
	Node *p=new Node();
	while(temp->next!=NULL)
	{
		temp=temp->next;
	}
	temp=p;
	
	while(p->prev!=NULL)
	{
		temp=temp->prev;
	}
	
	
}
int main()
{
	Node *head=new Node();
	Node *second=new Node();
	Node *third=new Node();
	Node *four=new Node();
	Node *five=new Node();
	Node *six=new Node();
	head->next=second;
	head->data=45;
	head->prev=NULL;
	second->next=third;
	second->data=34;
	second->prev=head;
	third->next=four;
	third->data=67;
	third->prev=second ;
	four->next=five;
	four->data=56;
	four->prev=third;
	five->next=six;
	five->data=68;
	five->prev=four;
	six->next=NULL;
	six->data=34;
	six->prev=five ;
	traverse(head);
	cout<<"after reverse the linklist\n";
	reverse(head);
	traverse(head);
	return 0;
}

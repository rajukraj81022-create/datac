public class BFS {

    static class QUEUE {
        int Rear = -1;
        int Front = -1;
        int size = 30;
        Node[] arr = new Node[size];   // FIXED: should store Node

        int IsEmpty() {
            if (Front == -1 || Front > Rear) {
                return 1;
            } else {
                return 0;
            }
        }

        Node Push(Node Root) {
            arr[++Rear] = Root;
            if (Front == -1) {
                Front++;
            }
            return Root;
        }

        Node Pop() {
            if (IsEmpty() == 1) {
                return null;
            }
            return arr[Front++];   // FIXED 🚀
        }
    }

    static class Node {
        int data;
        Node Left;
        Node Right;

        Node(int data) {
            this.data = data;
            this.Left = null;
            this.Right = null;
        }
    }

    static int indx = -1;

    public static Node CreateTree(int node[]) {
        indx++;
        if (node[indx] == -1) {
            return null;
        }
        Node Root = new Node(node[indx]);
        Root.Left = CreateTree(node);
        Root.Right = CreateTree(node);
        return Root;
    }

    void BFSearch(Node Root) {
        QUEUE obj = new QUEUE();
        obj.Push(Root);
        obj.Push(null); // level marker

        while (obj.IsEmpty() != 1) {
            Node Curr = obj.Pop();

            if (Curr == null) {
                System.out.println();

                if (obj.IsEmpty() == 0) {
                    obj.Push(null); // new level
                }
            } else {
                System.out.print(Curr.data + " ");

                if (Curr.Left != null) obj.Push(Curr.Left);
                if (Curr.Right != null) obj.Push(Curr.Right);
            }
        }
    }
    
    int CountNode(Node Root)
    {
         
        if(Root==null)
        {
            return 0;
        }
        
       int LeftTree= CountNode(Root.Left);
        int RightTree=CountNode(Root.Right);
        return LeftTree+RightTree+1;
    }

    public static void main(String[] args) {
        BFS obj = new BFS();

        int node[] = {6, 4, 1, -1, -1, 5, -1, -1, 8, 7, -1, -1, 9, -1, -1};

        Node Root = obj.CreateTree(node);

        System.out.println("BFS Traversal:");
        obj.BFSearch(Root);
        System.out.println("Number of Nodes");
        System.out.println(obj.CountNode(Root));
    
    }
}

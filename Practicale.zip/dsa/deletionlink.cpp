#include<iostream>
using namespace std;
class Node{
	public:
	int data;
	Node *next;
};
// this function use for travese in linked list 
void traverse(Node *head )
{
	while(head!=NULL )
	{
		cout<<head->data<<"\n";
		head=head->next;
	}
}
// this function use insertion in linklist
Node *insertatindex(Node *head,int val,int index)
{
	Node *p=new Node();   // create a new node 
	if(index<0)    //  
	{
		cout<<"invalid index number\n";
	}
	else if(index==0)
	{
		Node *ptr=new Node();
		ptr->next=head;
		ptr->data=val;
		return ptr;
	}
	else{
		
	Node *temp=new Node();
	temp=head;
	int i=0;
	while(temp->next!=NULL && i!=index-1)
	{
		temp=temp->next;
		i++;
	}
	
	if( temp->next==NULL)
	{
		cout<<"out of scope \n";
	}
	else{
		p->next=temp->next;
		p->data=val;
		temp->next=p;
		
	}
	}
	
}
Node *deletindex(Node *head,int index)
{
	Node *temp=new Node();
	Node *p=new Node();
	temp=head;
	p=head->next;
	int i=1;
	while(temp->next!=NULL && i!=index-1)
	{
		temp=temp->next;
		p=p->next;
		i++;
	}
	temp->next=p->next;
	free (p);
	return head;
}
Node *delethead(Node *head)
{
	Node *ptr=new Node();
	ptr=head;
	head=head->next;
	free (ptr);
	return head;
}
Node *deletend(Node *head)
{
	Node *temp=new Node();
	Node *q =new Node();
	temp=head;
	q=head->next;
	while(q->next!=NULL)
	{
		temp=temp->next;
		q=q->next;
	}
	temp->next=NULL;
	free (q);
	return head;
}
//delete ata given value of linklist 
Node *givenvalue(Node *head,int val)  // this function not work for head node 
{
	Node *temp=new Node();
	Node *q=new Node();
	temp=head;
	q->data=val;
	q=head->next;
	while(q->next!=NULL && q->data!=val )
	{
		temp=temp->next;
		q=q->next;
	}
	if(q->next==NULL)
	{
		cout<<"given value does not exist in linklist\n";
	}
	else{
		temp->next=q->next;
		free(q);
		return head;
	}
	
}
int main()
{
	Node *head=new Node();
	Node *second=new Node();
	Node *third=new Node();
	head->data=45;
	head->next=second;
	second->data=56;
	second->next=third;
	third->data=78;
	third->next=NULL;
	int index;
	cout<<"ENTER THE INDEX NUMBER\n";
	cin>>index;
	traverse( head);
	cout<<"after insertion \n";
	if(index==0){
		
	head=insertatindex(head,89,index);
	}
	else{
		insertatindex(head,89,index);
	}
	
	traverse(head);
	/*
	cout<<"AFTER THE DELETION OF any index\n";
	deletindex(head,2);
	traverse(head);
	cout<<"after delete at head\n";
	
	head=delethead(head);
	traverse(head);
	cout<<"aftre delete at end \n";
	deletend(head);
	traverse(head);
	**/
	///givenvalue(head,56);
	//traverse(head);
	return 0;
} 
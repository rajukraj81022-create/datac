public class InorderPredecessor 
 {
    static class Node
    {
        int data;
        Node Left;
        Node Right;
        Node(int data)
        {
            this.data=data;
            this.Left=null;
            this.Right=null;
        }
    }
    static int indx=-1;
    public static Node CreateTree(int node[])
    {
        indx++;
        if(node[indx]==-1)
        {
            return null;
        }
        Node newnode=new Node(node[indx]);
        newnode.Left=CreateTree(node);
        newnode.Right=CreateTree(node);
        return newnode;
    }
    void InOrder(Node Root)
    {
        if(Root==null)
        {
            return;
        }
        InOrder(Root.Left);
        System.out.println(Root.data);
        InOrder(Root.Right);
    }
    int RightMostInLeft(Node Root)
    {
        int ans=0;
        Root=Root.Left;
        while(Root!=null)
        {
            ans=Root.data;
            Root=Root.Right;
        }
        return ans;
    }
    int LeftMostInRightSubtree(Node Root)
    {
        int ans=0;
        Root=Root.Right;
        while(Root!=null)
        {
            ans=Root.data;
            Root=Root.Left;
        }
        return ans;
    }
    void Predecessor(Node Root,int data)
    {
        int pred=-1;
        int Succ=-1;
        while(Root!=null)
        {
        if(data<Root.data)
        {
         Succ=Root.data;
         Root=Root.Left;   
        }
        else if(data>Root.data)
        {
            pred=Root.data;
            Root=Root.Right;
        }
        else
        {
            if(Root.Left!=null)
            {
                pred=RightMostInLeft(Root);
            }
            if(Root.Right!=null)
            {
                Succ=LeftMostInRightSubtree(Root);
            }
        break;
        }
    
    }
     System.out.println("Predecessor is :  " +pred +  "  Sucessor is :  " +Succ);
    }
        public static void main(String[] args)
        {
            InorderPredecessor obj=new InorderPredecessor();
            int node[]={6,4,1,-1,-1,5,-1,-1,8,7,-1,-1,9,-1,-1};
            Node Root=obj.CreateTree(node);
            System.out.println("InOrder Traversal");
            obj.InOrder(Root);
            System.out.println("inorder Predecessor and Succesor");
            obj.Predecessor(Root, 8);

        }
    
    
}

#include <bits/stdc++.h>

using namespace std;
class Node {
    public: int data;
    Node * next;
};
void traverse(Node * ptr) {
    while (ptr != NULL)
    {
        cout << ptr -> data << "\n";
        ptr = ptr -> next;
    }
}

// insert at head 
Node * insertathead(Node * ptr, int val)
{
    Node * p = new Node();
    p -> next = ptr;
    p -> data = val;
    return p;
}
/// insert at any index 
Node * insertatindex(Node * head, int val, int index)
{
    Node * p = new Node();
    Node * ptr = new Node();
    p = head;
    int i = 1;
    while (p->next!=NULL && i != index)
    {
        if(p->next==NULL)
        {
            cout<<"given index is out of scope \n";
        }
        p = p -> next;
        i++;
    }
    ptr->data=val;
    ptr -> next = p -> next;
    p->next = ptr;
    return head;
}
void insertatend(Node *head,int val)
{
    Node *ptr=new Node();
    Node *temp=new Node();
    temp=head;
    ptr->data=val;
    while(temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=ptr;
    ptr->next=NULL;
}
void atgivennode(Node *head,Node *previous,int val )
{
    Node *temp=new Node();
    temp->data=val;
    temp->next=previous->next;
    previous->next=temp;
}
int main() {
    Node * head = new Node();
    Node * second = new Node();
    Node * third = new Node();
    head -> data = 13;
    head -> next = second;
    second -> data = 34;
    second -> next = third;
    third -> data = 56;
    third -> next = NULL;
    traverse(head);
    // head = insertathead(head, 45);
    // traverse(head);
    // cout << "insert at index \n";
    // insertatindex(head, 44, 2);
    // traverse(head);
    // cout<<"Insert at end of Node \n";
    // insertatend(head,78);
    // traverse(head);
    cout<<"after insert at given node \n";
    atgivennode(head,second,79);
    traverse(head);
    return 0;
    
    
    
    
    
    
    
}
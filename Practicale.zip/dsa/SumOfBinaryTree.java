import java.util.LinkedList;
import java.util.Queue;
public class SumOfBinaryTree {
    static class Node{
        int data;
        Node Left;
        Node Right;
        Node(int data)
        {
            this.data=data;
            this.Left=null;
            this.Right=null;
        }
    }
    static int indx=-1;
Node CreateTree(int node[])
{
    indx++;
    if(node[indx]==-1)
    {
        return null;
    }
    Node Root=new Node(node[indx]);
    Root.Left=CreateTree(node);
    Root.Right=CreateTree(node);
    return Root;

}
void BFSearch(Node Root)
{
    Queue<Node>q=new LinkedList<>();
q.add(Root);
q.add(null);
    while(!q.isEmpty())
    {
        Node curr=q.remove();
        if(curr==null)
        {
            System.out.println(" ");
         if(q.isEmpty())
        {
            break;
        }
        else{
            q.add(null);
        }
        }
        else{
            System.out.print(curr.data+" ");
            if(curr.Left!=null)
            {
                q.add(curr.Left);
            }
            if(curr.Right!=null)
            {
                q.add(curr.Right);
            }
        }
    }
}
int SumOfNode(Node Root)
{
    
    if(Root==null)
    {
        return 0;
    }
    int LeftSum=SumOfNode(Root.Left);
    int RightSum=SumOfNode(Root.Right);
    return LeftSum+RightSum+Root.data; 
}
public static void main(String[]args)
{
    SumOfBinaryTree obj=new SumOfBinaryTree();
    int node[] = {6, 4, 1, -1, -1, 5, -1, -1, 8, 7, -1, -1, 9, -1, -1};
   Node Root= obj.CreateTree(node);
   obj.BFSearch(Root);
    System.out.println("Sum of Root is ="+obj.SumOfNode(Root));


}
}

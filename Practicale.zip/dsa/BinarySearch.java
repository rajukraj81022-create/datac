import java.util.Scanner;

// import javax.lang.model.util.ElementScanner14;
public class BinarySearch
{
     static class Node
	 {
		 int data;
		 Node Left;
		 Node Right;
		 Node(int data)
		 {
			 this.data=data;
			 this.Right=null;
			 this.Left=null;;
		 }
			 
	 }
	 Node Insert(Node Root,int data)
	 {
		 
		 if(Root==null)
		 {
			return Root=new Node(data);
		 }
		 if(Root.data<data)
		 {
			 Root.Right=Insert(Root.Right,data);
		 }
		 else
		 {
			  Root.Left=Insert(Root.Left,data);
		 }
		 return Root;
	 }
	 Node TakeInpupt(Node Root)
	 {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter the data");
		 int data=sc.nextInt();
		 while(data!=-1)
		 {
			 Root=Insert(Root,data);
			 System.out.println("Enter the data");
			  data=sc.nextInt();
		 }
		 return Root;
	 }
	 // INORDER ORDER
	 void Inorder(Node Root)
	 {
		 if(Root==null)
		 {
			 return;
		 }
		 Inorder( Root.Left);
		 System.out.println(Root.data);
		 Inorder(Root.Right);
	 }
	 // PREORDER TRAVERSAL
	 void PreOrder(Node Root)
	 {
		 if(Root==null)
		 {
			 return;
		 }
		 System.out.println(Root.data);
		 PreOrder(Root.Left);
		 PreOrder(Root.Right);
	 }
	 // POST ORDER TRAVERSAL
	 void PostOrder(Node Root)
	 {
		 if(Root==null)
		 {
			 return;
		 }
		 PostOrder(Root.Left);
		 PostOrder(Root.Right);
		 System.out.println(Root.data);
	 }
	 //  INSERTION IN BINARY  SEARCH
	 void InsertionNode(Node Root,int data)
	 {
		Node ptr=new Node(data);
		Node temp=null;
		while(Root!=null)
		{

			temp=Root;
		if(Root.data==data)
		{
			System.out.println("Element Already exist");
			return;
		}
		else if(Root.data<data)
		{
			
		 Root=Root.Right;
		}
		else
		{
		
			Root=Root.Left;
		}
	}
		if(temp.data<data)
		{
			temp.Right=ptr;
		}
		else{
			temp.Left=ptr;
		}
	
      return;

	 }
	public static void main(String[] args)
	{
		BinarySearch tree=new BinarySearch();
		Node Root=null;
		Root=tree.TakeInpupt(Root);
		System.out.println("Inorder Traversal");
		tree.Inorder(Root);
		System .out.println("PreOrder Traversal");
		tree.PreOrder(Root);
		System.out.println("PostOrder Traversal");
		tree.PostOrder(Root);
		System.out.println("After Insertion ");
		tree.InsertionNode(Root,67);
		tree.Inorder(Root);
		
		
	}
}
#include<iostream>
using namespace std;
class Node{
	public:
	int data;
	Node *next;
};
void traverse(Node *head)
{
	Node *temp=new Node();
	temp=head;
	do
	{
		cout<<temp->data<<"\n";
		
		temp=temp->next;
	}
	while(temp!=head);
}
Node *inserthead(Node *head,int val)
{
	Node *temp=new Node();
	Node *p=new Node();
	p->data=val;
	temp=head;
	while(temp->next!=head)
	{
		temp=temp->next;
	}
	temp->next=p;
	p->next=head;
	head=p;
	return head;
	
}
Node *index(Node *head,int val, int index)
{
	Node *temp=new Node();
	temp=head;
	Node *p=new Node();
	p->data=val;
	int i=1;
	if(index<0)
	{
		cout<<"enter the valid index\n";
	}
	 else if(index==0)
	 {
		while(temp->next!=head)
	{
		temp=temp->next;
	}
	temp->next=p;
	p->next=head;
	head=p;
	return head;
	 }
    		
	else
	{
		
	 while(temp->next!=head && i!=index)
	 {
		temp=temp->next;
		i++;
	 }
	 if(i!=index)
	 {
		 cout<<"out of scope \n";
	 }
	 else
	 {	 
	  p->next=temp->next;
	  temp->next=p;
	  }
	} 
}

int main()
{
	Node *head=new Node();
	Node *second=new Node();
	Node *third=new Node();
	Node *four=new Node();
	head->data=23;
	head->next=second;
	second->data=45;
	second->next=third;
	third->data=78;
	third->next=four;
	four->data=79;
	four->next=head;
	traverse(head);
	cout<<"after insertion at head   \n";
   //head=inserthead(head,67);
   //head=inserthead(head,670);
 //  head=inserthead(head,671);
   
	//traverse(head);
	
	cout<<"insert at any index number \n";
	int ind;
	cout<<"inter the index\n";
	cin>>ind;
	if(ind==0)
	{
	 head=index(head,56,ind);
	}
	else{
		index(head,56,ind);
	}
	traverse(head);
	
	return 0; 
}